package org.lys.mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import org.lys.pojo.FileInfo;
import java.util.List;

public interface FileInfoMapper {
    Integer countByPage(@Param("schName") String schName,@Param("schStime") String schStime,@Param("schEtime") String schEtime,@Param("schStatus") String schStatus);

    List<FileInfo> quenyByPage(@Param("schName")String schName,@Param("schStime") String schStime,@Param("schEtime") String schEtime,@Param("schStatus") String schStatus, RowBounds rowBounds);

    Integer updateFileInfo(@Param("iStatus") int iStatus,@Param("iId") int iId);

    FileInfo selectByFileId(@Param("iId") int iId);
}
