package org.lys.service;

import org.apache.ibatis.annotations.Param;
import org.lys.pojo.LogInfo;

import java.util.List;

public interface AdminLogInfoService {

    List<LogInfo> quenyByPage( Integer id, String schStime, String schEtime, String start, String end);

    Integer countByPage(Integer id, String schStime, String schEtime);

    Integer dodeleteLogById( int iId);
}
