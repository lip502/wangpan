package org.lys.service;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.lys.mapper.AdminLogInfoMapper;
import org.lys.mapper.FileTypeMapper;
import org.lys.pojo.Admin;
import org.lys.pojo.FileType;
import org.lys.pojo.LogInfo;
import org.lys.util.SqlSessionUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service
public class FileTypeServiceImpl implements FileTypeService{
    @Resource
    private FileTypeMapper fileTypeMapper; // 这里的Mapper就是Spring负责扫描到实例化出来的Mapper对象
    @Resource
    private AdminLogInfoMapper adminLogInfoMapper;
    @Override
    public List<FileType> quenyByPage(String fileName, String sScore, String eScore, String start, String end) {
//        SqlSession session =  SqlSessionUtil.getSqlSession();
//        FileTypeMapper Mapper = session.getMapper(FileTypeMapper.class); //拿到adminMapper
        //非空判断
        if (fileName.equals("")){
            fileName = null;
        }
        if (sScore.equals("")){
            sScore = null;
        }
        if (eScore.equals("")){
            eScore = null;
        }

//        List<FileType> fileType = Mapper.selectByPage(fileName,sScore,eScore,
//                new RowBounds(Integer.parseInt(start),Integer.parseInt(end)));
//        session.commit();
//        session.close();
        return fileTypeMapper.selectByPage(fileName,sScore,eScore,
                new RowBounds(Integer.parseInt(start),Integer.parseInt(end)));
    }
    //条数
    @Override
    public Integer countByPage(String fileName, String sScore, String eScore) {
//        SqlSession session =  SqlSessionUtil.getSqlSession();
//        FileTypeMapper Mapper = session.getMapper(FileTypeMapper.class); //拿到adminMapper
        //非空判断
        if (fileName.equals("")){
            fileName = null;
        }
        if (sScore.equals("")){
            sScore = null;
        }
        if (eScore.equals("")){
            eScore = null;
        }
//        Integer count = Mapper.countByPage(fileName,sScore,eScore);
//        session.commit();
//        session.close();
        return fileTypeMapper.countByPage(fileName,sScore,eScore);
    }
    //删除文件类型
    @Override
    public Integer dodeleteById(int iId, Admin admin) {
//        SqlSession session =  SqlSessionUtil.getSqlSession();
//        FileTypeMapper Mapper = session.getMapper(FileTypeMapper.class);
//        Integer index = Mapper.dodeleteById(iId);
//        session.commit();
//        session.close();
        //增加日志
        LogInfo logInfo = new LogInfo();
        logInfo.setAdminId(admin.getId());
        logInfo.setContentInfo("管理员"+admin.getAccount()+"删除了文件id为"+iId+"的类型");
        adminLogInfoMapper.insertLogInfo(logInfo);
        return fileTypeMapper.dodeleteById(iId);
    }
    //新增文件类型
    @Override
    public Integer createFileType(FileType fileType,Admin admin) {
//        SqlSession session =  SqlSessionUtil.getSqlSession();
//        FileTypeMapper Mapper = session.getMapper(FileTypeMapper.class);
//        Integer index = Mapper.createFileType(fileType);
//        session.commit();
//        session.close();  //增加日志
        LogInfo logInfo = new LogInfo();
        logInfo.setAdminId(admin.getId());
        logInfo.setContentInfo("管理员"+admin.getAccount()+"新增了文件类型"+fileType.getTypeLastName());
        adminLogInfoMapper.insertLogInfo(logInfo);
        return fileTypeMapper.createFileType(fileType);
    }
    //修改
    @Override
    public Integer doUpdateInfo(String updateType, String updateName, long iUpdateScore, String updateId,Admin admin) {
//        SqlSession session =  SqlSessionUtil.getSqlSession();
//        FileTypeMapper Mapper = session.getMapper(FileTypeMapper.class);
//        Integer index = Mapper.doUpdateInfo(updateType,updateName,iUpdateScore,updateId);
//        session.commit();
//        session.close();
        LogInfo logInfo = new LogInfo();
        logInfo.setAdminId(admin.getId());
        logInfo.setContentInfo("管理员"+admin.getAccount()+"修改了文件类型id为"+updateId+"的信息");
        adminLogInfoMapper.insertLogInfo(logInfo);
        return fileTypeMapper.doUpdateInfo(updateType,updateName,iUpdateScore,updateId);
    }
}
