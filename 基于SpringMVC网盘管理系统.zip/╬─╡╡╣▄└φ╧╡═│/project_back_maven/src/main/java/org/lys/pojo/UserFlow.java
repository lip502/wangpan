package org.lys.pojo;

import java.sql.Date;

public class UserFlow {
    private Integer id;
    private Integer userId;
    private Integer scoreStatus;
    private Integer score;
    private Date regDate;

    public UserFlow() {
    }

    public UserFlow(Integer id, Integer userId, Integer scoreStatus, Integer score, Date regDate) {
        this.id = id;
        this.userId = userId;
        this.scoreStatus = scoreStatus;
        this.score = score;
        this.regDate = regDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getScoreStatus() {
        return scoreStatus;
    }

    public void setScoreStatus(Integer scoreStatus) {
        this.scoreStatus = scoreStatus;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Date getRegDate() {
        return regDate;
    }

    public void setRegDate(Date regDate) {
        this.regDate = regDate;
    }
}
