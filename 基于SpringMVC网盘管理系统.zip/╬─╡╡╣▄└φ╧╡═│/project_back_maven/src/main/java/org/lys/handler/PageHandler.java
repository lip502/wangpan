package org.lys.handler;
import org.lys.pojo.Admin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
public class PageHandler {
    @GetMapping("page.do")
    public ModelAndView pager(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String p = req.getParameter("p");
        // 重定向，转发
        // 因为转发的效率是比较高的，所以不论是框架还是插件都推荐使用转发的形式进行页面跳转
        // 如果携带上来的参数为空（没有携带参数），就跳转到登录界面，否则跳转到对应的界面
        if(p == null || p.equals("")) {
            // req.getRequestDispatcher("WEB-INF/html/login.html").forward(req, resp);
            return new ModelAndView("login_back");
        }else {
            // 判断是否有session，如果有，则跳转，否则跳转回登录
            Admin admin = (Admin) req.getSession().getAttribute("admin");
            // req.getRequestDispatcher("WEB-INF/html/" + (adminInfo == null ? "login" : p) + ".html").forward(req, resp);
            return new ModelAndView((admin == null ? "login" : p));
        }
    }

    @GetMapping("doExit.do")
    public void exit(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.getSession().invalidate();
        resp.sendRedirect("page.do");
    }
}
