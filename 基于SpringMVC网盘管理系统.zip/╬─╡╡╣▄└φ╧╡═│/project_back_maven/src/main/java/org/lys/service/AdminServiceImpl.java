package org.lys.service;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.lys.mapper.AdminLogInfoMapper;
import org.lys.mapper.AdminMapper;
import org.lys.mapper.RegScoreMapper;
import org.lys.pojo.Admin;
import org.lys.pojo.LogInfo;
import org.lys.util.SqlSessionUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service
public class AdminServiceImpl implements AdminService {
    @Resource
    private AdminMapper adminMapper; // 这里的Mapper就是Spring负责扫描到实例化出来的Mapper对象
    @Resource
    private RegScoreMapper regScoreMapper;
    @Resource
    private AdminLogInfoMapper adminLogInfoMapper;
    //admin登陆事务
    @Override
    public Admin Login(String account, String pwd) {
//        SqlSession session =  SqlSessionUtil.getSqlSession(); //util中获得session
//        AdminMapper adminMapper = session.getMapper(AdminMapper.class); //拿到adminMapper
//        Admin admin = adminMapper.selectByNameAndPsd(account,pwd); //调取登陆的方法
//        session.commit(); //提交
//        session.close(); //关闭
        return adminMapper.selectByNameAndPsd(account,pwd); //返回
    }
    //多条件查询
    @Override
    public List<Admin> quenyByPage(String adminName, String schRole,String startTime, String endTime, String iStartRn, String iEndRn) {
        //util中获得session
//        SqlSession session =  SqlSessionUtil.getSqlSession();
//        AdminMapper adminMapper = session.getMapper(AdminMapper.class); //拿到adminMapper
        //非空判断
        if (adminName.equals("")){
            adminName = null;
        }
        if (schRole.equals("0")){
            schRole = null;
        }
        if (startTime.equals("")){
            startTime = null;
        }
        if (endTime.equals("")){
            endTime = null;
        }

//        List<Admin> admins = adminMapper.selectByPage(adminName,schRole,startTime,endTime,
//                new RowBounds(Integer.parseInt(iStartRn),Integer.parseInt(iEndRn)));
//        session.commit();
//        session.close();
        return adminMapper.selectByPage(adminName,schRole,startTime,endTime,
                new RowBounds(Integer.parseInt(iStartRn),Integer.parseInt(iEndRn)));
    }
    //总条数
    @Override
    public Integer countByPage(String adminName, String schRole,String startTime, String endTime) {
//        SqlSession session =  SqlSessionUtil.getSqlSession(); //util中获得session
//        AdminMapper adminMapper = session.getMapper(AdminMapper.class); //拿到adminMapper
        //非空判断
        if (adminName.equals("")){
            adminName = null;
        }
        if (schRole.equals("0")){
            schRole = null;
        }
        if (startTime.equals("")){
            startTime = null;
        }
        if (endTime.equals("")){
            endTime = null;
        }
//        Integer count = adminMapper.countByPage(adminName,schRole,startTime,endTime);
//        session.commit();
//        session.close();
//        System.out.println("10.31+"+count);
        return adminMapper.countByPage(adminName,schRole,startTime,endTime);
    }

    //重置密码
    @Override
    public Integer updateByPwd(int iId,Admin admin) {
//        SqlSession session =  SqlSessionUtil.getSqlSession(); //util中获得session
//        AdminMapper adminMapper = session.getMapper(AdminMapper.class); //拿到adminMapper
//        Integer index = adminMapper.updateByPwd(iId);
//        session.commit();
//        session.close();
        //增加日志
        LogInfo logInfo = new LogInfo();
        logInfo.setAdminId(admin.getId());
        logInfo.setContentInfo("管理员"+admin.getAccount()+"重置了管理员的id为"+iId+"的密码");
        adminLogInfoMapper.insertLogInfo(logInfo);
        return adminMapper.updateByPwd(iId);
    }

    //新增管理员
    @Override
    public Integer createAdmin(Admin admin) {
//        SqlSession session =  SqlSessionUtil.getSqlSession(); //util中获得session
//        AdminMapper adminMapper = session.getMapper(AdminMapper.class); //拿到adminMapper
//        Integer index = adminMapper.createAdmin(admin);
//        session.commit();
//        session.close();
        return adminMapper.createAdmin(admin);
    }

    //禁用启用
    @Override
    public Integer doOpenClose(int iStatus,int iId,Admin admin) {
//        SqlSession session =  SqlSessionUtil.getSqlSession(); //util中获得session
//        AdminMapper adminMapper = session.getMapper(AdminMapper.class); //拿到adminMapper
//        Integer index = adminMapper.doOpenClose(iStatus,iId);
//        session.commit();
//        session.close();
        //增加日志
        LogInfo logInfo = new LogInfo();
        logInfo.setAdminId(admin.getId());
        logInfo.setContentInfo("管理员"+admin.getAccount()+"禁用了管理员的id为"+iId+"的禁用启用状态");
        adminLogInfoMapper.insertLogInfo(logInfo);
        return adminMapper.doOpenClose(iStatus,iId);
    }


    //修改管理员信息
    @Override
    public Integer editAdminById(String editName, String editRole, String editId,Admin admin) {
        LogInfo logInfo = new LogInfo();
        logInfo.setAdminId(admin.getId());
        logInfo.setContentInfo("管理员"+admin.getAccount()+"修改了管理员的id为"+editId+"的信息");
        adminLogInfoMapper.insertLogInfo(logInfo);
        return adminMapper.updateById(editName,editRole,editId);
    }

    @Override
    public  Integer doEditRegScore(int iId) {
//        SqlSession session =  SqlSessionUtil.getSqlSession(); //util中获得session
//        RegScoreMapper regScoreMapper = session.getMapper(RegScoreMapper.class); //拿到adminMapper
//        System.err.println(iId);
//        Integer index = regScoreMapper.doEditRegScore(iId);
//        session.commit();
//        session.close();
        return regScoreMapper.doEditRegScore(iId);
    }

}
