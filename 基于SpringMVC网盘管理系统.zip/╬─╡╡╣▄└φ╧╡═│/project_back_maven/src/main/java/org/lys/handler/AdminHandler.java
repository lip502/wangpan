package org.lys.handler;
import org.lys.dto.JsonMsg;
import org.lys.pojo.Admin;
import org.lys.pojo.Role;
import org.lys.service.AdminService;
import org.lys.service.RoleService;
import org.lys.util.Ajax;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;


@RestController
public class AdminHandler {

    @Resource
    private AdminService adminService;
    @Resource
    private RoleService roleService;
    private JsonMsg msg = new JsonMsg();
    //查询admin角色信息
    @GetMapping("initRole.do")
    protected JsonMsg initRole(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonMsg msg = new JsonMsg();
        List<Role> roles = roleService.queryAll();
        msg.getDatas().put("roles",roles);
        return msg;
    }
    //多条件查询及分页显示
    @GetMapping("initAdmin.do")
    protected JsonMsg initAdmin(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String schName = req.getParameter("schName");
        String schRole = req.getParameter("schRole");
        String schStime = req.getParameter("schStime");
        String schEtime = req.getParameter("schEtime");
        String start = req.getParameter("start");
        String end = req.getParameter("end");
//        AdminService adminService = ServiceFactory.newInstance().getServiceObj(AdminService.class);
        List<Admin> admins =  adminService.quenyByPage(schName,schRole,schStime,schEtime,start,end);
        Integer count = adminService.countByPage(schName,schRole,schStime,schEtime);
        JsonMsg msg = new JsonMsg();
        msg.getDatas().put("admins", admins);
        msg.getDatas().put("counts", count);
//        resp.getWriter().println(JSONObject.toJSONString(msg));
        return msg;
    }


    //重置密码
    @PostMapping("doResetPwd.do")
    protected JsonMsg doPostPassword(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        AdminService adminService = ServiceFactory.newInstance().getServiceObj(AdminService.class);
        JsonMsg msg = new JsonMsg();
        String id = req.getParameter("id");
        int iId = -1;
        try {
            iId = Integer.parseInt(id);
        } catch (NumberFormatException e) {
            Ajax.error(resp, "id错了");
            return null;
        }
        Admin admin = (Admin) req.getSession().getAttribute("admin");
        Integer index = adminService.updateByPwd(iId,admin);
        if (index != null) {
            msg.setId(0);
            msg.setMsg("重置密码成功！");
        } else {
            msg.setId(1);
            msg.setMsg("重置密码失败！");
        }
//            resp.getWriter().println(JSONObject.toJSONString(msg));
        return msg;
    }
    //新增管理员
    @PostMapping("docreateAdmin.do")
    protected JsonMsg docreateAdmin(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String account = req.getParameter("account");
        String password = req.getParameter("password");
        String role = req.getParameter("role");
        JsonMsg msg = new JsonMsg();
        int iRole = -1;
        try {
            iRole = Integer.parseInt(role);
        } catch (NumberFormatException e) {
            Ajax.error(resp, "id错了");
            return null;
        }
        Admin admin = new Admin(0, account, password, 1, null, iRole);
        Integer index = adminService.createAdmin(admin);
        if (index != 0) {
            msg.setMsg("新增管理员成功！");
        } else {
            msg.setMsg("新增管理员失败！");
        }
//        resp.getWriter().println(JSONObject.toJSONString(msg));
        return msg;
    }
    //禁用启用
    @PostMapping("doOpenClose.do")
    protected JsonMsg doOpenClose(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String status = req.getParameter("status");
        Admin admin = (Admin) req.getSession().getAttribute("admin");
        String id = req.getParameter("id");
        JsonMsg msg = new JsonMsg();
        int iId = -1;
        try {
            iId = Integer.parseInt(id);
        } catch (NumberFormatException e) {
            msg.setMsg("id错了");
            return msg;
        }
        int iStatus = -1;
        try {
            iStatus = Integer.parseInt(status);
        } catch (NumberFormatException e) {
            msg.setMsg("状态错了");
            return msg;
        }
        Integer index = adminService.doOpenClose(iStatus,iId,admin);
        if (index != null) {
            msg.setId(0);
            msg.setMsg("禁用成功！");
        } else {
            msg.setId(1);
            msg.setMsg("禁用失败！");
        }
//        resp.getWriter().println(JSONObject.toJSONString(msg));
        return msg;
    }
    //修改用户信息
    @PostMapping("editAdmin.do")
    protected JsonMsg editAdmin(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String editName = req.getParameter("editName");
        String editRole = req.getParameter("editRole");
        String editId = req.getParameter("editId");
        Admin admin = (Admin) req.getSession().getAttribute("admin");
        JsonMsg msg = new JsonMsg();
//        AdminService adminService = ServiceFactory.newInstance().getServiceObj(AdminService.class);
        Integer index = adminService.editAdminById(editName,editRole,editId,admin);
        int id = index > 0 ? 0: 1;
        String message = index > 0?"修改成功":"修改数据失败";
        msg.setMsg(message);
        msg.setId(id);
//        resp.getWriter().println(JSONObject.toJSONString(msg));
        return msg;
    }

}
