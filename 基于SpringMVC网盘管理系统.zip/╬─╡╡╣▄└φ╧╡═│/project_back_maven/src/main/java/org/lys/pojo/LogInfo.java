package org.lys.pojo;

import java.sql.Date;

public class LogInfo {

    private long id;
    private long adminId;
    private String contentInfo;
    private Date doDate;

    public LogInfo() {
    }

    public LogInfo(long id, long adminId, String contentInfo, Date doDate) {
        this.id = id;
        this.adminId = adminId;
        this.contentInfo = contentInfo;
        this.doDate = doDate;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getAdminId() {
        return adminId;
    }

    public void setAdminId(long adminId) {
        this.adminId = adminId;
    }

    public String getContentInfo() {
        return contentInfo;
    }

    public void setContentInfo(String contentInfo) {
        this.contentInfo = contentInfo;
    }

    public Date getDoDate() {
        return doDate;
    }

    public void setDoDate(Date doDate) {
        this.doDate = doDate;
    }
}
