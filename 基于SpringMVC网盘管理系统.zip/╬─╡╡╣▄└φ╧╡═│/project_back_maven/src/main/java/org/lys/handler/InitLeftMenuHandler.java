package org.lys.handler;
import com.alibaba.fastjson.JSONObject;
import org.lys.dto.JsonMsg;
import org.lys.pojo.Admin;
import org.lys.pojo.Menu;
import org.lys.service.MenuService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@RestController
public class InitLeftMenuHandler {
    @Resource
    private MenuService menuService;
    @PostMapping("menu.do")
    protected JsonMsg doPostMenu(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //拿到管理员菜单id
        Admin admin = (Admin) req.getSession().getAttribute("admin");
        Integer role = admin.getRole();
//        MenuService menuService =  ServiceFactory.newInstance().getServiceObj(MenuService.class);
        List<Menu> list = menuService.innitLeftMenu(role);
        JsonMsg msg = new JsonMsg();
        msg.getDatas().put("menus",list);
//        resp.getWriter().println(JSONObject.toJSONString(msg));
        return msg;
    }
}
