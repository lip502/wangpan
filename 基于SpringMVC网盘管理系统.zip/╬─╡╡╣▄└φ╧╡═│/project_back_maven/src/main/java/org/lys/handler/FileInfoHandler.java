package org.lys.handler;
import org.apache.commons.io.FileUtils;
import org.lys.dto.JsonMsg;
import org.lys.mapper.CustomerMapper;
import org.lys.mapper.FileTypeMapper;
import org.lys.pojo.FileInfo;
import org.lys.service.FileInfoService;
import org.lys.vo.FileInfos;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RestController
public class FileInfoHandler {
    @Value("#{config.path}")
    private String str;
    @Resource
    private FileInfoService fileInfoService;
    @Resource
    private FileTypeMapper fileTypeMapper;
    @Resource
    private CustomerMapper customerMapper;

    @GetMapping("AdminFileAction.do")
    protected JsonMsg AdminFileAction(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonMsg msg = new JsonMsg();
        String schName = req.getParameter("schName");
        String schStatus = req.getParameter("schStatus");
        String schStime = req.getParameter("schStime");
        String schEtime = req.getParameter("schEtime");
        String start = req.getParameter("start");
        String end = req.getParameter("end");
        //多条件查询
        List<FileInfo> fileInfo = fileInfoService.quenyByPage(schName, schStime, schEtime,schStatus, start, end);
        //new新的vo对象集合
        List<FileInfos> fileInfos = new ArrayList<>();
        //遍历fileInfo
        for (int i = 0;i<fileInfo.size();i++){
            //再次查询文件类型和用户姓名（根据文件的类型id和用户id）
            String fileTypeName = fileTypeMapper.selectFileStypeName(fileInfo.get(i).getFileStyle());
            String fileCustomerName = customerMapper.selectFileCustomerName(fileInfo.get(i).getCustomsId());
            //new vo对象
            FileInfos files = new FileInfos();
            files.setId(fileInfo.get(i).getId());
            files.setFileStyle(fileInfo.get(i).getFileStyle());
            files.setCustomsId(fileInfo.get(i).getCustomsId());
            files.setFileName(fileInfo.get(i).getFileName());
            files.setFileSize(fileInfo.get(i).getFileSize());
            files.setFileDate(fileInfo.get(i).getFileDate());
            files.setFileTypeName(fileTypeName);
            files.setFileScore(fileInfo.get(i).getFileScore());
            files.setFileCustomerName(fileCustomerName);
            files.setFileStatus(fileInfo.get(i).getFileStatus());
            fileInfos.add(files);
        }
        Integer count = fileInfoService.countByPage(schName, schStime, schEtime,schStatus);
        msg.getDatas().put("fileInfos", fileInfos);
        msg.getDatas().put("counts", count);
        return msg;
    }

    //审核通过
    @PostMapping("doFileOK.do")
    public JsonMsg doFileOK(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        JsonMsg msg = new JsonMsg();
        String status = req.getParameter("status");
        String id = req.getParameter("id");
        String customsId = req.getParameter("customsId");

        int iId = -1;
        try {
            iId = Integer.parseInt(id);
        } catch (NumberFormatException e) {
            msg.setMsg("id错了");
            return msg;
        }
        int iStatus = -1;
        try {
            iStatus = Integer.parseInt(status);
        } catch (NumberFormatException e) {
            msg.setMsg("状态错了");
            return msg;
        }
        int iCustomsId = -1;
        try {
            iCustomsId = Integer.parseInt(customsId);
        } catch (NumberFormatException e) {
            msg.setMsg("用户id错了");
            return msg;
        }
        Integer index = fileInfoService.updateFileInfo(iStatus,iId,iCustomsId);
        if (index!=null){
            msg.setMsg("审核通过操作成功");
        }else{
            msg.setMsg("审核操作失败");
        }
        return msg;
    }

    //审核不通过
    @PostMapping("doPassFile.do")
    public JsonMsg doPassFile(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonMsg msg = new JsonMsg();
        String status = req.getParameter("status");
        String id = req.getParameter("id");
        int iId = -1;
        try {
            iId = Integer.parseInt(id);
        } catch (NumberFormatException e) {
            msg.setMsg("id错了");
            return msg;
        }
        int iStatus = -1;
        try {
            iStatus = Integer.parseInt(status);
        } catch (NumberFormatException e) {
            msg.setMsg("状态错了");
            return msg;
        }
        Integer index = fileInfoService.updatePassFileInfo(iStatus,iId);
        if (index!=null){
            msg.setMsg("操作成功");
        }else{
            msg.setMsg("操作失败");
        }
        return msg;
    }

    private FileInfo file = null;
    //admin下载首页文件
    @PostMapping("adminDowmLoadFile.do")
    public JsonMsg adminDowmLoadFile(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonMsg msg = new JsonMsg();
        String id = req.getParameter("id");
        int iId = -1;
        try {
            iId = Integer.parseInt(id);
        } catch (NumberFormatException e) {
            msg.setMsg("id出错");
            return msg;
        }
        msg = fileInfoService.selectFileInfoById(iId);
        if (msg.getId() == 0) {
            file = (FileInfo) msg.getDatas().get("file");
        }
        return msg;
    }



    //文件下载
    @GetMapping("fileDowmload.do")
    public void download(HttpServletRequest req, HttpServletResponse resp) {
//        String fileName = "文件上传和下载.txt";
//        String path = "C://";
        try {
            // 1.设置输出文件类型，是以流的方式进行输出
            resp.setContentType("application/octet-stream; charset=utf-8");
            // 2.设置该文件用来下载，并且下载的文件名是xxx
            String fileEncode = new String(file.getFileName().getBytes("UTF-8"), "ISO8859-1");
            resp.setHeader("Content-Disposition", "attachment; filename=" + fileEncode);
            // 3.通过IO流将文件写出
            FileUtils.copyFile(new java.io.File(str + file.getFileName()), resp.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



}
