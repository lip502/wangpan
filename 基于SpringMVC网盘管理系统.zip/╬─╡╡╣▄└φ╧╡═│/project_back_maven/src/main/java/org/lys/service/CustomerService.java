package org.lys.service;

import org.lys.pojo.Admin;
import org.lys.pojo.Customer;

import java.util.ArrayList;

public interface CustomerService {
    ArrayList<Customer> select(String userName, String phone, String email, String startTime, String endTime, int iStartRn, int iEndRn);

    int getTotal(String userName, String phone, String email, String startTime, String endTime);

    Integer doOpenClose(Admin admin, int iStatus, int iId);

}
