package org.lys.pojo;


import java.sql.Date;

public class Menu {

    private Long id;
    private String menuName;
    private String menuUrl;
    private Integer pid;
    private String img;
    private Date regDate;
    private Integer menuStatus;

    public Menu() {
    }

    public Menu(Long id, String menuName, String menuUrl, Integer pid, String img, Date regDate, Integer menuStatus) {
        this.id = id;
        this.menuName = menuName;
        this.menuUrl = menuUrl;
        this.pid = pid;
        this.img = img;
        this.regDate = regDate;
        this.menuStatus = menuStatus;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public String getMenuUrl() {
        return menuUrl;
    }

    public void setMenuUrl(String menuUrl) {
        this.menuUrl = menuUrl;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public Date getRegDate() {
        return regDate;
    }

    public void setRegDate(Date regDate) {
        this.regDate = regDate;
    }

    public Integer getMenuStatus() {
        return menuStatus;
    }

    public void setMenuStatus(Integer menuStatus) {
        this.menuStatus = menuStatus;
    }
}
