package org.lys.handler;
import org.lys.dto.JsonMsg;
import org.lys.service.AdminService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
public class EditRegScoreHandler {
    @Resource
    private AdminService adminService;
    @PostMapping("doEditRegScore.do")
    public JsonMsg doEditRegScore(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonMsg msg = new JsonMsg();
        String id = req.getParameter("id");
        int iId = -1;
        try {
            iId = Integer.parseInt(id);
        } catch (NumberFormatException e) {
            msg.setMsg("分数错了！");
            return msg;
        }
//        AdminService adminService = ServiceFactory.newInstance().getServiceObj(AdminService.class);
        Integer index = adminService.doEditRegScore(iId);
        if (index != null) {
            msg.setId(0);
            msg.setMsg("修改注册积分成功！");
        } else {
            msg.setId(1);
            msg.setMsg("修改注册积分失败！");
        }
//        resp.getWriter().println(JSONObject.toJSONString(msg));
        return msg;

    }
}
