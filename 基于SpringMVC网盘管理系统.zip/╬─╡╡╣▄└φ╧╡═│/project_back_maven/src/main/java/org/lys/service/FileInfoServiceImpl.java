package org.lys.service;
import org.apache.ibatis.session.RowBounds;
import org.lys.dto.JsonMsg;
import org.lys.mapper.CustomerMapper;
import org.lys.mapper.FileInfoMapper;
import org.lys.mapper.UserFlowMapper;
import org.lys.pojo.Customer;
import org.lys.pojo.FileInfo;
import org.lys.pojo.UserFlow;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
@Service
public class FileInfoServiceImpl implements FileInfoService{
    @Resource
    private FileInfoMapper fileInfoMapper;
    @Resource
    private CustomerMapper customerMapper;
    @Resource
    private UserFlowMapper userFlowMapper;

    @Override
    public Integer countByPage(String schName, String schStime, String schEtime, String schStatus) {
        if (schName.equals("")){
            schName = null;
        }
        if (schStime.equals("")){
            schStime = null;
        }
        if (schEtime.equals("")){
            schEtime = null;
        }
        if (schStatus.equals("0")){
            schStatus = null;
        }
//        System.err.println("schName"+schName);
//        System.err.println("schStatus"+schStatus);
//        System.err.println("schStime"+schStime);
//        System.err.println("schEtime"+schEtime);
        return fileInfoMapper.countByPage(schName,schStime,schEtime,schStatus);
    }

    @Override
    public List<FileInfo> quenyByPage(String schName, String schStime, String schEtime, String schStatus, String start, String end) {
        if (schName.equals("")){
            schName = null;
        }
        if (schStime.equals("")){
            schStime = null;
        }
        if (schEtime.equals("")){
            schEtime = null;
        }
        if (schStatus.equals("0")){
            schStatus = null;
        }
        return fileInfoMapper.quenyByPage(schName,schStime,schEtime,schStatus,new RowBounds(Integer.parseInt(start),Integer.parseInt(end)));
    }

    //管理员审核用户上传文件通过事务
    @Override
    public Integer updateFileInfo(int iStatus, int iId,int iCustomsId) {
        //修改状态
        Integer index = fileInfoMapper.updateFileInfo(iStatus,iId);
        //用户增加积分
        Customer customer = new Customer();
        //拿到类型积分表的对应类型
        customer.setId(iCustomsId);
        index = customerMapper.updateCustomer(customer,iId);
        //加入用户积分流水表
        index = userFlowMapper.createUserFlow(iCustomsId,iId);
        return index;
    }

    //操作审核不通过
    @Override
    public Integer updatePassFileInfo(int iStatus, int iId) {

        return fileInfoMapper.updateFileInfo(iStatus,iId);
    }

    //admin下载文件
    @Override
    public JsonMsg selectFileInfoById(int iId) {
        JsonMsg msg = new JsonMsg();
        FileInfo fileInfo = fileInfoMapper.selectByFileId(iId); //获得文件id对应的用户id
        msg.setId(0);
        msg.getDatas().put("file",fileInfo);
        return msg;
    }
}
