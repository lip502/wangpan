package org.lys.service;

import org.lys.dto.JsonMsg;
import org.lys.pojo.FileInfo;

import java.util.List;

public interface FileInfoService {
    Integer countByPage(String schName, String schStime, String schEtime, String schStatus);

    List<FileInfo> quenyByPage(String schName, String schStime, String schEtime, String schStatus, String start, String end);

    Integer updateFileInfo(int iStatus, int iId,int iCustomsId);

    Integer updatePassFileInfo(int iStatus, int iId);

    JsonMsg selectFileInfoById(int iId);
}
