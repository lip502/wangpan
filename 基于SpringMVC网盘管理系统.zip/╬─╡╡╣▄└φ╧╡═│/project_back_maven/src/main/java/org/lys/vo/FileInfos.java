package org.lys.vo;

import java.sql.Date;

public class FileInfos {
    private long id;
    private String fileName;
    private Date fileDate;
    private Integer fileStatus;
    private Integer fileStyle;
    private Integer customsId;
    private Integer adminId;
    private Integer fileSize;
    private String fileUrl;
    private Integer fileScore;
    private String fileTypeName;
    private String fileCustomerName;

    public FileInfos() {
    }

    public FileInfos(long id, String fileName, Date fileDate, Integer fileStatus, Integer fileStyle, Integer customsId, Integer adminId, Integer fileSize, String fileUrl, Integer fileScore, String fileTypeName, String fileCustomerName) {
        this.id = id;
        this.fileName = fileName;
        this.fileDate = fileDate;
        this.fileStatus = fileStatus;
        this.fileStyle = fileStyle;
        this.customsId = customsId;
        this.adminId = adminId;
        this.fileSize = fileSize;
        this.fileUrl = fileUrl;
        this.fileScore = fileScore;
        this.fileTypeName = fileTypeName;
        this.fileCustomerName = fileCustomerName;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Date getFileDate() {
        return fileDate;
    }

    public void setFileDate(Date fileDate) {
        this.fileDate = fileDate;
    }

    public Integer getFileStatus() {
        return fileStatus;
    }

    public void setFileStatus(Integer fileStatus) {
        this.fileStatus = fileStatus;
    }

    public Integer getFileStyle() {
        return fileStyle;
    }

    public void setFileStyle(Integer fileStyle) {
        this.fileStyle = fileStyle;
    }

    public Integer getCustomsId() {
        return customsId;
    }

    public void setCustomsId(Integer customsId) {
        this.customsId = customsId;
    }

    public Integer getAdminId() {
        return adminId;
    }

    public void setAdminId(Integer adminId) {
        this.adminId = adminId;
    }

    public Integer getFileSize() {
        return fileSize;
    }

    public void setFileSize(Integer fileSize) {
        this.fileSize = fileSize;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public Integer getFileScore() {
        return fileScore;
    }

    public void setFileScore(Integer fileScore) {
        this.fileScore = fileScore;
    }

    public String getFileTypeName() {
        return fileTypeName;
    }

    public void setFileTypeName(String fileTypeName) {
        this.fileTypeName = fileTypeName;
    }

    public String getFileCustomerName() {
        return fileCustomerName;
    }

    public void setFileCustomerName(String fileCustomerName) {
        this.fileCustomerName = fileCustomerName;
    }
}
