package org.lys.mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import org.lys.pojo.FileType;
import java.util.List;

public interface FileTypeMapper {
    List<FileType> selectByPage(@Param("fileName") String fileName, @Param("sScore") String sScore, @Param("eScore") String eScore, @Param("") RowBounds rowBounds);

    Integer countByPage(@Param("fileName") String fileName, @Param("sScore") String sScore, @Param("eScore") String eScore);

    Integer dodeleteById(@Param("iId") int iId);

    Integer createFileType(@Param("fileType") FileType fileType);

    Integer doUpdateInfo(@Param("updateType") String updateType, @Param("updateName") String updateName, @Param("iUpdateScore") long iUpdateScore, @Param("updateId") String updateId);

    String selectFileStypeName(@Param("fileStyle") Integer fileStyle);
}
