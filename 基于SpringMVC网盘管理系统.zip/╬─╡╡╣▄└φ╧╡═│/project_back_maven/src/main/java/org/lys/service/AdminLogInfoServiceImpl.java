package org.lys.service;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.lys.mapper.AdminLogInfoMapper;
import org.lys.mapper.CustomerMapper;
import org.lys.pojo.LogInfo;
import org.lys.util.SqlSessionUtil;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
@Service
public class AdminLogInfoServiceImpl implements AdminLogInfoService{
    @Resource
    private AdminLogInfoMapper adminLogInfoMapper; // 这里的Mapper就是Spring负责扫描到实例化出来的Mapper对象

    @Override
    public List<LogInfo> quenyByPage(Integer id, String schStime, String schEtime, String start, String end) {
        //非空判断
        if ("".equals(schStime)){
            schStime = null;
        }
        if ("".equals(schEtime)){
            schEtime = null;
        }
        return adminLogInfoMapper.selectByPage(id,schStime,schEtime,
                new RowBounds(Integer.parseInt(start),Integer.parseInt(end)));
    }

    @Override
    public Integer countByPage(Integer id, String schStime, String schEtime) {
//        SqlSession session =  SqlSessionUtil.getSqlSession();
//        AdminLogInfoMapper adminLogInfoMapper = session.getMapper(AdminLogInfoMapper.class); //拿到adminMapper
        //非空判断
        if ("".equals(schStime)){
            schStime = null;
        }
        if ("".equals(schEtime)){
            schEtime = null;
        }
//        Integer count = adminLogInfoMapper.countByPage(id,schStime,schEtime);
//        session.commit();
//        session.close();
        return adminLogInfoMapper.countByPage(id,schStime,schEtime);
    }

    @Override
    public Integer dodeleteLogById(int iId) {
        return adminLogInfoMapper.dodeleteLogById(iId);
    }


}
