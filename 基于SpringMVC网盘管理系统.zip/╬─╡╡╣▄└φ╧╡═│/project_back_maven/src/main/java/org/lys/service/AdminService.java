package org.lys.service;

import org.lys.pojo.Admin;

import java.util.ArrayList;
import java.util.List;

public interface AdminService {
    Admin Login(String account, String pwd);

    Integer updateByPwd(int iId,Admin admin);

    Integer createAdmin(Admin admin);

    Integer doOpenClose(int iStatus, int iId,Admin admin);

    List<Admin> quenyByPage(String schName, String schRole, String schStime, String schEtime, String start, String end);

    Integer countByPage(String schName, String schRole, String schStime, String schEtime);

    //修改管理员信息
    Integer editAdminById(String editName, String editRole, String editId,Admin admin);

    //修改注册奖励积分
    Integer doEditRegScore(int iId);
}
