package org.lys.service;

import org.lys.pojo.Admin;
import org.lys.pojo.FileType;

import java.util.List;

public interface FileTypeService {
    List<FileType> quenyByPage(String fileName, String sScore, String eScore, String start, String end);

    Integer countByPage(String fileName, String sScore, String eScore);

    Integer dodeleteById(int iId, Admin admin);

    Integer createFileType(FileType fileType,Admin admin);

    Integer doUpdateInfo(String updateType, String updateName, long iUpdateScore, String updateId,Admin admin);
}
