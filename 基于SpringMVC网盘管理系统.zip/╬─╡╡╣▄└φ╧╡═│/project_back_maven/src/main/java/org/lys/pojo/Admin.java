package org.lys.pojo;
import java.sql.Date;

public class Admin {
    private Integer id;
    private String account;
    private String password;
    private Integer statues;
    private Date regDate;
    private Integer role;

    public Admin() {
    }

    public Admin(Integer id, String account, String password, Integer statues, Date regDate, Integer role) {
        this.id = id;
        this.account = account;
        this.password = password;
        this.statues = statues;
        this.regDate = regDate;
        this.role = role;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getStatues() {
        return statues;
    }

    public void setStatues(Integer statues) {
        this.statues = statues;
    }

    public Date getRegDate() {
        return regDate;
    }

    public void setRegDate(Date regDate) {
        this.regDate = regDate;
    }

    public Integer getRole() {
        return role;
    }

    public void setRole(Integer role) {
        this.role = role;
    }
}
