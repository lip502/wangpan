package org.lys.service;
import org.apache.ibatis.session.SqlSession;
import org.lys.mapper.FileTypeMapper;
import org.lys.mapper.MenuMapper;
import org.lys.pojo.Menu;
import org.lys.util.SqlSessionUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service
public class MenuServiceImpl implements MenuService {
    @Resource
    private MenuMapper menuMapper; // 这里的Mapper就是Spring负责扫描到实例化出来的Mapper对象
    @Override
    public List<Menu> innitLeftMenu(Integer role) {
//        SqlSession session =  SqlSessionUtil.getSqlSession(); //util中获得session
//        MenuMapper menuMapper = session.getMapper(MenuMapper.class); //拿到adminMapper
//        List<Menu> list = menuMapper.selectByRole(role);
//        session.commit();
//        session.close();
        return menuMapper.selectByRole(role);
    }
}
