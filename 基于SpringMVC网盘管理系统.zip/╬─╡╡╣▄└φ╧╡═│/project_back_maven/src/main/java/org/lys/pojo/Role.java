package org.lys.pojo;

public class Role {
    private long id;
    private String roleName;
    private String regDate;
    private Integer roleStatus;

    public Role() {
    }

    public Role(long id, String roleName, String regDate, Integer roleStatus) {
        this.id = id;
        this.roleName = roleName;
        this.regDate = regDate;
        this.roleStatus = roleStatus;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getRegDate() {
        return regDate;
    }

    public void setRegDate(String regDate) {
        this.regDate = regDate;
    }

    public Integer getRoleStatus() {
        return roleStatus;
    }

    public void setRoleStatus(Integer roleStatus) {
        this.roleStatus = roleStatus;
    }
}
