package org.lys.service;

import org.lys.pojo.Role;

import java.util.List;

public interface RoleService {
    List<Role> queryAll();
}
