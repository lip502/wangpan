package org.lys.mapper;

import org.lys.pojo.Role;

import java.util.List;

public interface RoleMapper {
    List<Role> selectAll();
}
