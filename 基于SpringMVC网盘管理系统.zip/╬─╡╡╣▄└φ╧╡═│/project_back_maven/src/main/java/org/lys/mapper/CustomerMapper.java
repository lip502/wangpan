package org.lys.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import org.lys.pojo.Customer;

import java.util.ArrayList;

public interface CustomerMapper {

    //分页加多条件
    int getTotal(@Param("name") String userName, @Param("phone") String phone,
                 @Param("email") String email, @Param("startTime") String startTime,
                 @Param("endTime") String endTime);
    //多条件查询
    ArrayList<Customer> select(@Param("name") String userName, @Param("phone") String phone,
                               @Param("email") String email, @Param("startTime") String startTime,
                               @Param("endTime") String endTime, RowBounds rb);
    //禁用启用
    Integer doOpenClose(@Param("iStatus") int iStatus, @Param("iId") int iId);

    //增加用户积分
    Integer updateCustomer(@Param("customer") Customer customer,@Param("iId") int iId);

    String selectFileCustomerName(@Param("customsId") Integer customsId);
}
