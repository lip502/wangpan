package org.lys.mapper;

import org.apache.ibatis.annotations.Param;

public interface RegScoreMapper {
    Integer doEditRegScore(@Param("iId") int iId);
}
