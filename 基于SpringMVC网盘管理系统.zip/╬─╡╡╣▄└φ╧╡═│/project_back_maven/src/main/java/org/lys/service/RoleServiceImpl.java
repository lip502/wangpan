package org.lys.service;
import org.apache.ibatis.session.SqlSession;
import org.lys.mapper.MenuMapper;
import org.lys.mapper.RoleMapper;
import org.lys.pojo.Role;
import org.lys.util.SqlSessionUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service
public class RoleServiceImpl implements RoleService{
    @Resource
    private RoleMapper roleMapper; // 这里的Mapper就是Spring负责扫描到实例化出来的Mapper对象
    @Override
    public List<Role> queryAll() {
//        SqlSession session =  SqlSessionUtil.getSqlSession(); //util中获得session
//        RoleMapper roleMapper = session.getMapper(RoleMapper.class); //拿到adminMapper
//        List<Role> list = roleMapper.selectAll();
//        session.commit();
//        session.close();
        return roleMapper.selectAll();
    }
}
