package org.lys.aop;
import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MyAop {
    /**
     * execution() 默认
     *   public 查询的方法是public修饰的
     *   * 代表返回值无所谓，如果找返回String类型，则写上：java.lang.String
     *   org.lgs.service.* 找的是service里面的所有类
     *   * 所有类里面的所有方法
     *   (..) 任意参数，如果找参数String类型，则写上：java.lang.String
     */
    // @Before("execution(public * org.lgs.service.*.*(..))")
    // public void doAccessCheck() {
    // System.out.println("hehe");
    // }
    private Logger logger = Logger.getLogger(MyAop.class);
    @Around("execution(public * org.lys.service.*.*(..))")
    public Object doBasicProfiling(ProceedingJoinPoint pjp) throws Throwable {
        try{
            Object retVal = pjp.proceed();
            return retVal;
        }catch (Exception ex) {
            System.out.println("你出错了...");
            ex.printStackTrace(); // 打印在控制台
            logger.error(ex.getMessage());
        }
        return null;
    }
}
