package org.lys.mapper;
import org.apache.ibatis.annotations.Param;
import org.lys.pojo.Menu;
import java.util.List;

public interface MenuMapper {
    List<Menu> selectByRole(@Param("role") Integer role);
}
