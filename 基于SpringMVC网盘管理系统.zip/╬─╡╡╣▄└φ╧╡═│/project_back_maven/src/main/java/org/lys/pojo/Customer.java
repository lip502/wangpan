package org.lys.pojo;


import java.sql.Date;

public class Customer {

    private long id;
    private String account;
    private String userName;
    private String password;
    private Date regDate;
    private Integer status;
    private Integer sex;
    private String education;
    private String work;
    private String email;
    private String phone;
    private long score;

    public Customer() {
    }

    public Customer(long id, String account, String userName, String password, Date regDate, Integer status, Integer sex, String education, String work, String email, String phone, long score) {
        this.id = id;
        this.account = account;
        this.userName = userName;
        this.password = password;
        this.regDate = regDate;
        this.status = status;
        this.sex = sex;
        this.education = education;
        this.work = work;
        this.email = email;
        this.phone = phone;
        this.score = score;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Date getRegDate() {
        return regDate;
    }

    public void setRegDate(Date regDate) {
        this.regDate = regDate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getWork() {
        return work;
    }

    public void setWork(String work) {
        this.work = work;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public long getScore() {
        return score;
    }

    public void setScore(long score) {
        this.score = score;
    }
}
