package org.lys.mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import org.lys.pojo.Admin;
import java.util.List;

public interface AdminMapper {
    //登陆
    Admin selectByNameAndPsd(@Param("name") String name, @Param("psd") String psd);
    //多条件查询
    List<Admin> selectByPage(@Param("schName") String schName, @Param("schRole") String schRole,
                             @Param("schStime") String schStime,
                             @Param("schEtime") String schEtime, RowBounds rb);
    //条数
    Integer countByPage(@Param("schName") String schName, @Param("schRole") String schRole,
                        @Param("schStime") String schStime,
                        @Param("schEtime") String schEtime);
    //修改信息
    Integer updateById(@Param("editName") String editName, @Param("editRole") String editRole,
                       @Param("editId") String editId);
    //重置密码
    Integer updateByPwd(@Param("iId") int iId);
    //新增管理员
    Integer createAdmin(@Param("admin") Admin admin);
    //禁用启用
    Integer doOpenClose(@Param("iStatus") int iStatus, @Param("iId") int iId);
}
