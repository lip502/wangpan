package org.lys.pojo;

public class RegScore {

    private long id;
    private long regId;

    public RegScore() {
    }

    public RegScore(long id, long regId) {
        this.id = id;
        this.regId = regId;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getRegId() {
        return regId;
    }

    public void setRegId(long regId) {
        this.regId = regId;
    }
}
