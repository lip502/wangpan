package org.lys.handler;
import org.lys.dto.JsonMsg;
import org.lys.pojo.Admin;
import org.lys.service.AdminService;
import org.lys.util.Captcha;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.IOException;

@RestController
public class LoginHandler {
    @Resource
    private AdminService adminService;
    @PostMapping("doLogin.do")
    protected JsonMsg doPostLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        JsonMsg msg = new JsonMsg();
        String name = request.getParameter("name");
        String pwd = request.getParameter("pwd");
        String code = request.getParameter("code");
        String sessionCode = (String) request.getSession().getAttribute("captchaCode");
            if (null == code || !code.equalsIgnoreCase(sessionCode)) {
                msg.setId(1);
                msg.setMsg("验证码错误，请重新输入");
                return null;
            }
            Admin admin = adminService.Login(name,pwd);
            if (admin.getStatues()==1){
                if (admin != null){
                    request.getSession().setAttribute("admin",admin);
                    msg.setId(0);
                    msg.setMsg("登陆成功！");
                    msg.setLocation("main_back");
                }else{
                    msg.setId(1);
                    msg.setMsg("登陆失败！用户名或密码错误。。");
                }
            }else{
                msg.setId(3);
                msg.setMsg("登陆失败！账号被禁用。");
            }
        return msg;
    }

    //验证码
    @GetMapping("captcha.do")
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Captcha capt = new Captcha();
        BufferedImage img = capt.getImage();
        //响应输出流
        String code = capt.getCode();
        //把code存在session里面
        req.getSession().setAttribute("captchaCode", code);
        ServletOutputStream os = resp.getOutputStream();
        ImageIO.write(img, "jpeg", os);
    }

}
