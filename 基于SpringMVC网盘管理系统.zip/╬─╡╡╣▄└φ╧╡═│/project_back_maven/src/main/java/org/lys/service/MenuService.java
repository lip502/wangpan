package org.lys.service;

import org.lys.pojo.Menu;

import java.util.List;

public interface MenuService {
    List<Menu> innitLeftMenu(Integer role);
}
