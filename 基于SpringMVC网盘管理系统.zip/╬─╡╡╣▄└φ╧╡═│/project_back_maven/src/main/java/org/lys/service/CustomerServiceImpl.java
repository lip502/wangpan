package org.lys.service;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.lys.mapper.AdminLogInfoMapper;
import org.lys.mapper.CustomerMapper;
import org.lys.pojo.Admin;
import org.lys.pojo.Customer;
import org.lys.pojo.LogInfo;
import org.lys.util.SqlSessionUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
@Service
public class CustomerServiceImpl implements CustomerService{
    @Resource
    private CustomerMapper customerMapper; // 这里的Mapper就是Spring负责扫描到实例化出来的Mapper对象
    @Resource
    private AdminLogInfoMapper adminLogInfoMapper;
    @Override
    public ArrayList<Customer> select(String userName, String phone, String email, String startTime,
                                      String endTime, int iStartRn, int iEndRn) {

//        SqlSession session =  SqlSessionUtil.getSqlSession();
//            CustomerMapper customerMapper = session.getMapper(CustomerMapper.class);
            if (userName.equals("")){
                userName = null;
            }
            if (phone.equals("")){
                phone = null;
            }
            if (email.equals("")){
                email = null;
            }
            if (startTime.equals("")){
                startTime = null;
            }
            if (endTime.equals("")){
                endTime = null;
            }
//            ArrayList<Customer> list = customerMapper.select(userName, phone,email,startTime, endTime,
//                    new RowBounds(iStartRn,iEndRn));
            return customerMapper.select(userName, phone,email,startTime, endTime,
                    new RowBounds(iStartRn,iEndRn));
    }

    @Override
    public int getTotal(String userName, String phone, String email, String startTime, String endTime) {

//           SqlSession session =  SqlSessionUtil.getSqlSession();
//            // 5. 获取接口实例
//            CustomerMapper customerMapper = session.getMapper(CustomerMapper.class);
            if (userName.equals("")){
                userName = null;
            }
            if (phone.equals("")){
                phone = null;
            }
            if (email.equals("")){
                email = null;
            }
            if (startTime.equals("")){
                startTime = null;
            }
            if (endTime.equals("")){
                endTime = null;
            }
//            int total = customerMapper.getTotal(userName,phone,email,startTime,endTime);
//            session.commit();
//            session.close();
            return customerMapper.getTotal(userName,phone,email,startTime,endTime); // 把list return出去

    }
    //禁用启用
    @Override
    public Integer doOpenClose(Admin admin, int iStatus, int iId) {
//        SqlSession session =  SqlSessionUtil.getSqlSession(); //util中获得session
//        CustomerMapper customerMapper = session.getMapper(CustomerMapper.class); //拿到adminMapper
//        Integer index = customerMapper.doOpenClose(iStatus,iId);
        //拿到admin增加日志的mapper
//        AdminLogInfoMapper adminLogInfoMapper =  session.getMapper(AdminLogInfoMapper.class);
       //增加日志
        LogInfo logInfo = new LogInfo();
        logInfo.setAdminId(admin.getId());
        logInfo.setContentInfo("管理员"+admin.getAccount()+"修改了用户id为"+iId+"的禁用/启用状态");
        adminLogInfoMapper.insertLogInfo(logInfo);
//        session.commit();
//        session.close();
        return customerMapper.doOpenClose(iStatus,iId);
    }
}
