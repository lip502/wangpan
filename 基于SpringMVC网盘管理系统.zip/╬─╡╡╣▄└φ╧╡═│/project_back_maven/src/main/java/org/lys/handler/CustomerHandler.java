package org.lys.handler;
import org.lys.dto.JsonMsg;
import org.lys.pojo.Admin;
import org.lys.pojo.Customer;
import org.lys.service.CustomerService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@RestController
public class CustomerHandler {
    @Resource
    private CustomerService customerService;
    @GetMapping("customer.do")
    protected JsonMsg customer(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String startRn = req.getParameter("startRn");
        String endRn = req.getParameter("endRn");
        JsonMsg msg = new JsonMsg();
            String userName = req.getParameter("userName");
            String phone = req.getParameter("phone");
            String email = req.getParameter("email");
            String startTime = req.getParameter("startTime");
            String endTime = req.getParameter("endTime");
            // 字符串转整型
            int iStartRn = -1;
            int iEndRn = -1;
            try {
                iStartRn = Integer.parseInt(startRn);
            } catch (NumberFormatException e) {
                msg.setMsg("分页的开始数字错了");
                return null;
            }
            try {
                iEndRn = Integer.parseInt(endRn);
            } catch (NumberFormatException e) {
                msg.setMsg("分页的结束数字错了");
                return null;
            }
            ArrayList<Customer> customers = customerService.select(userName, phone,email,startTime, endTime, iStartRn, iEndRn);
             msg.getDatas().put("customers", customers);
             int total = customerService.getTotal(userName, phone,email,startTime, endTime);
             msg.getDatas().put("total", total);
            return msg;
    }

    //禁用
    @PostMapping("doOpenCloseUser.do")
    protected JsonMsg doOpenCloseUser(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonMsg msg = new JsonMsg();
        Admin admin = (Admin) req.getSession().getAttribute("admin");
        String status = req.getParameter("status");
        String id = req.getParameter("id");
        int iId = -1;
        try {
            iId = Integer.parseInt(id);
        } catch (NumberFormatException e) {
            msg.setMsg("id错了");
            return null;
        }
        int iStatus = -1;
        try {
            iStatus = Integer.parseInt(status);
        } catch (NumberFormatException e) {
            msg.setMsg("状态错了");
            return null;
        }
        Integer index = customerService.doOpenClose(admin,iStatus,iId);
        if (index != null) {
            msg.setId(0);
            msg.setMsg("禁用成功！");

        } else {
            msg.setId(1);
            msg.setMsg("禁用失败！");
        }
    return msg;
    }

}
