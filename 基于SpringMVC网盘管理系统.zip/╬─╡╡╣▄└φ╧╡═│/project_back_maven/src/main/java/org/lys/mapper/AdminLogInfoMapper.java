package org.lys.mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import org.lys.pojo.LogInfo;
import java.util.List;

public interface AdminLogInfoMapper {

    List<LogInfo> selectByPage(@Param("id") Integer id,@Param("schStime") String schStime,@Param("schEtime") String schEtime, RowBounds rowBounds);

    Integer countByPage(@Param("id")Integer id,@Param("schStime") String schStime,@Param("schEtime") String schEtime);

    Integer insertLogInfo(@Param("LogInfo") LogInfo logInfo);

    Integer dodeleteLogById(@Param("iId") int iId);
}
