package org.lys.mapper;

import org.apache.ibatis.annotations.Param;
import org.lys.pojo.UserFlow;

public interface UserFlowMapper {
    Integer insertUserFlow(@Param("userFlow") UserFlow userFlow);

    Integer createUserFlow(@Param("iCustomsId") int iCustomsId,@Param("iId") int iId);
}
