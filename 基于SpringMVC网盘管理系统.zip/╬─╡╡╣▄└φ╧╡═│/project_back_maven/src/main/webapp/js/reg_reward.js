function doEditRegScore(){
    var data = {
        id: document.getElementById('score').value
    }
    $.ajax({
        url: './doEditRegScore.do',
        type: 'POST',
        dataType: 'JSON',
        data: data,
        success: function (resp) {
            console.log(resp)
            layer.alert(resp.msg)
        },
        error: function (resp) {
            layer.alert(resp.msg);
        }
    })
}