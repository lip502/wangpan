//获取值的方法
function val(id) {
    return document.getElementById(id).value;
}

function set(id, key, val) {
    document.getElementById(id)[key] = val;
}

function get(id, key) {
    return document.getElementById(id)[key];
}

function html(id, str) {
    document.getElementById(id).innerHTML = str;
}

// 遮罩的开关打开

function show(id) {
    document.getElementById(id).style.display = "block";
}

function close(id) {
    document.getElementById(id).style.display = "none";
}

//通过name来获取单选框的值
function radioVal(name) {
    var radios = document.getElementsByName(name);
    for (var i = 0; i < radios.length; i++) {
        var r = radios[i];
        if (r.checked) {
            return r.value;
        }
    }
}

//多选的情况
function checkBoxVal(name) {
    var checkBoxs = document.getElementsByName(name);
    for (var i = 0; i < checkBoxs.length; i++) {
        var r = checkBoxs[i];
        if (r.checked) {
            arr.push(r.value);
        }
    }
    return arr;
}

