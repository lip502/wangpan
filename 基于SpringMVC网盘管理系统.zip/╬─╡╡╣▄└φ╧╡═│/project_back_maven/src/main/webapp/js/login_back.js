function doLogin() {
    layer.load(2);
    var data = {
        action: 'doLogin',
        name: val('name'),
        pwd: val('pwd'),
        code:val('code')
    };
    console.log(data);
    $.ajax({
        url: './doLogin.do',
        type: 'POST',
        data: data,
        dataType: 'JSON',
        success: function (resp) {
            layer.closeAll('loading');
            layer.alert(resp.msg, {
                closeBtn: 0
            }, function () {
                if (resp.id == 0) {
                    window.location.href = 'page.do?p=' + resp.location;
                }
            });
        },
        error: function (resp) {
            layer.closeAll('loading');
            layer.alert('请联系管理员...');
        }

    })
}

function changeImg() {
    var src = './captcha.do' + '?' + Math.random() ;
    set('capt-img', 'src', src);
}