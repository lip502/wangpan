    //一开始就打印
init();
//？？？
$('#tree').tree({
    animate: true
});
//初始打印菜单的方法
function init() {
    // layer.load(2);
    // 1.获取数据
    $.ajax({
        url: './menu.do',
        type: 'POST',
        dataType: 'JSON',
        success: function (resp) {
            console.log(resp);
            layer.closeAll('loading');
            var arr = resp.datas.menus;
            var treeArr = [];
            parseTree(arr,0,treeArr);
            console.log(treeArr);
            // 2.获取菜单对象
            var myTree = $('#tree').data('zui.tree');
            // 3.将数据渲染到菜单对象中
            myTree.reload(treeArr);
        },
        error: function (resp) {
            layer.closeAll('loading');
            layer.alert('请联系管理员...');
        }


    })


}

function parseTree(arr,pid,treeArr) {
    for(var i = 0; i < arr.length; i ++ ) {
        if(arr[i].pid == pid) {
            // 编辑我所需要的参数
            var jsonObj = {
                html: `<a href="#" onclick="changFrame('${arr[i].menuUrl}')">${arr[i].menuName}</a>`,
                children : []
            };
            // 将对应的参数添加到tree数组中
            treeArr.push(jsonObj);
            parseTree(arr, arr[i].id, jsonObj.children);
        }
    }
}

//右边菜单打印的方法
function changFrame(url) {
    if( url != 'undefined') {
       // document.getElementById('frame').src = url + ".html";
        document.getElementById('frame').src = "page.do?p=" + url;
    }

}
//退出
function doExit() {
    layer.confirm('你确定要退出系统吗?', {
        btn: ['确定'] //按钮
    }, function(){
        window.location.href = "doExit.do";
    });
}