var start = 0;
var end = 1;
var limit = 3;
var currPage = 1; //当前页
var allPage = 1;//总页数
var count = 0;
//初始化搜索数据变量
var _userName = '';
var _phone = '';
var _startTime = '';
var _endTime = '';
var _email = '';


//显示表格的方法
getList();
function getList() {
    var data = {
        startRn: start,
        endRn: limit,
        userName: _userName,
        phone: _phone,
        startTime: _startTime,
        endTime: _endTime,
        email: _email
    };
    $.ajax({
        url: './customer.do',
        type: 'GET',
        dataType: 'JSON',
        data: data,
        success: function (resp) {
            console.log(resp);
            customer = resp.datas.customers;
            count = resp.datas.total;
            if (customer == null || customer.length == 0) {
                currPage = 0;
                allPage = 0;
                layer.alert("暂无数据");
                document.getElementById('CustomerDatas').innerHTML = '';
            } else {
                var str = '';
                for (var i = 0; i < customer.length; i++) {
                    str += `
                     <tr>
                        <td>${customer[i].account}</td>
                        <td>${customer[i].userName}</td>
                        <td>${customer[i].sex == 0 ? '男' : '女'}</td>
                        <td>${customer[i].phone}</td>
                        <td>${customer[i].email}</td>
                        <td>${customer[i].regDate}</td>
                        <td>${customer[i].status == 1 ? '启用' : '禁用'}</td>
                        <td>
                            <button class="btn btn-mini" type="button" onclick="doOpenClose(${customer[i].status},${customer[i].id})" >${customer[i].status == 0 ? '启用' : '禁用'}</button>
                        </td>
                     </tr>`;
                }
                document.getElementById('CustomerDatas').innerHTML = str;
                //初始化分页数据
                allPage = count % limit == 0 ? (count / limit) : parseInt(count / limit + 1);
                document.getElementById('pageNum').innerHTML = currPage + "/" + allPage;
            }
        },
        error: function (resp) {
            layer.alert("请联系管理员")
        }
    })
}

//上一页
function prevPage() {
    if (currPage == 1) {
        layer.alert("已经是第一页了。")
    } else {
        currPage--;
        start -= limit;
        end -= limit;
        getList();
    }
}

//下一页
function nextPage() {
    if (currPage == allPage) {
        layer.alert("没有下一页了。")
    } else {
        currPage++;
        start += limit;
        end += limit;
        getList();
    }
}

//搜索
function doSearch() {
    start = 0;
    end = 1;
    limit = 3;
    currPage = 1; //当前页
    allPage = 1;//总页数
    count = 0;
//初始化搜索数据变量
    _userName = document.getElementById('userName').value;
    _phone = document.getElementById('phone').value;
    _startTime = document.getElementById('sTime').value;
    _endTime = document.getElementById('eTime').value;
    _email = document.getElementById('email').value;
    getList();
}

//判断禁用启用
function doOpenClose(index, id) {
    if (index == 1) {
        if (confirm("是否禁用")) {
            status(0, id) //这个是方法
        }
    } else {
        if (confirm("是否启用")) {
            status(1, id)
        }
    }
}

function status(index, id) {
    $.ajax({
        url: './doOpenCloseUser.do',
        type: 'POST',
        dataType: 'JSON',
        data: {
            status: index,
            id: id
        },
        success: function (resp) {
            console.log(resp);
            if (resp.id == 0) {
                layer.alert('修改状态成功');
                getList();
            }
        },
        error: function (resp) {
            layer.alert('修改状态失败');
        }
    })
}

