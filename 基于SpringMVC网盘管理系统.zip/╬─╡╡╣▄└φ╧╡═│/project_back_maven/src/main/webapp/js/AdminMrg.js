//初始化分页数据变量
var start = 0;
var end =1;
var limit = 3;
var currPage = 1; //当前页
var allPage = 1;//总页数
var count = 0;
//初始化搜索数据变量
var schName = '';
var schRole = 0;
var schStime = '';
var schEtime = '';
//角色信息的全局
var roles = null;
var admins = null;

//获得用户角色的方法
//初始化角色方法，一进去就有
initRole();
function initRole() {
    $.ajax({
        url: './initRole.do',
        type: 'GET',
        dataType: 'JSON',
        success: function (resp) {
            console.log(resp);
            //将角色信息加载到搜索的下拉框
            var str = '<option value="0">全部</option>';
            for(var i=0;i<resp.datas.roles.length;i++){
                str +=`<option value="${resp.datas.roles[i].id}">${resp.datas.roles[i].roleName }</option>`;
            }
                 document.getElementById('schRole').innerHTML = str;
            //2，保存到全局变量
            roles =  resp.datas.roles;
            getList();
        },
        error: function (resp) {
            layer.alert("请联系管理员")
        }
    })
}
//打印admin信息+多条件查询
function getList() {
    $.ajax({
        url: './initAdmin.do',
        type: 'GET',
        data:{
            start:start,
            end:limit,
            schName:schName,
            schRole:schRole,
            schStime:schStime,
            schEtime:schEtime
        },
        dataType: 'JSON',
        success: function (resp) {
            console.log(resp);
            admins = resp.datas.admins;
            count = resp.datas.counts;
            if (admins == null || admins.length == 0){
                currPage = 0;
                allPage = 0;
                layer.alert("暂无数据");
                document.getElementById('adminDatas').innerHTML = '';
            }else {
                var str = '';
                for (var i = 0;i<admins.length;i++){
                    str +=`
                     <tr>
                        <td>${admins[i].account}</td>
                        <td>${admins[i].regDate}</td>
                        <td>${admins[i].statues ==1?'启用':'禁用'}</td>
                        <td>${showRoleName(admins[i].role)}</td>
                        <td>
                            <button class="btn btn-mini" type="button" onclick="showEditPanel('${i}')">修改</button>
                            <button class="btn btn-mini" type="button" onclick="doResetPwd(${admins[i].id})">重置密码</button>
                            <button class="btn btn-mini" type="button" onclick="doOpenClose(${admins[i].statues},${admins[i].id})" >${admins[i].statues == 0 ? '启用' : '禁用'}</button>
                        </td>
            </tr>`;
                }
                document.getElementById('adminDatas').innerHTML = str;

                //初始化分页数据
                allPage = count%limit ==0?(count/limit):parseInt(count/limit+1);
                document.getElementById('pageNum').innerHTML = currPage+"/"+allPage;

            }
        },
        error: function (resp) {
            layer.alert("请联系管理员")
        }
    })
}


//表格显示角色名字方法  有可能报错的地方
function showRoleName(role) {
    for (var i = 0;i<roles.length;i++){
        if (roles[i].id == role){
            return roles[i].roleName;
        }
    }
}

//上一页
function prevPage() {
    if (currPage == 1){
        layer.alert("已经是第一页了。")
    }else {
        currPage--;
        start -=limit;
        end-=limit;
        getList();
    }
}
//下一页
function nextPage() {
    if (currPage == allPage){
        layer.alert("没有下一页了。")
    }else {
        currPage++;
        start +=limit;
        end+=limit;
        getList();
    }
}
//搜索
function doSearch() {

     start = 0;
     end =1;
     limit = 3;
     currPage = 1; //当前页
     allPage = 1;//总页数
     count = 0;
//初始化搜索数据变量
     schName = document.getElementById('schName').value;
     schRole = document.getElementById('schRole').value;
     schStime = document.getElementById('schStime').value;
     schEtime = document.getElementById('schEtime').value;
    getList();
}

//打开修改遮罩
function showEditPanel(index) {
    var admin = admins[index];
    document.getElementById('editAccount').value = admin.account;
    document.getElementById('editRole').value = admin.role;
    document.getElementById('editId').value = admin.id;
    $('#editAdmin').modal({
        backdrop: 'static', //背景遮罩
        position: 'fit', //最佳位置
        moveable: true, //可移动的
        rememberPos:true, //记住上次的位置
        scrollInside: true //是否在对话框内部显示滚动条
    })

}
//关闭遮罩
function hideEditModel() {
    $('#editAdmin').modal('hide', 'fit')
}
//修改管理员信息
function doEditAdmin() {
    var editName = document.getElementById('editAccount').value;
    var editRole = document.getElementById('editRole').value;
    var editId = document.getElementById('editId').value;
    $.ajax({
        url: './editAdmin.do',
        type: 'POST',
        data:{
            editName,editRole,editId
        },
        dataType: 'JSON',
        success: function (resp) {
            layer.alert(resp.msg);
            if (resp.id == 0){
                layer.alert("修改成功")
            }
            getList();
            hideEditModel();
        },
        error: function (resp) {
            layer.alert("请联系管理员")
        }
    })
}

//重置密码
function doResetPwd(id) {
    var data = {
        id: id,
        action: 'doResetPwd'
    }
    $.ajax({
        url: './doResetPwd.do',
        type: 'POST',
        dataType: 'JSON',
        data: data,
        success: function (resp) {
            console.log(resp)
            layer.alert(resp.msg)
        },
        error: function (resp) {
            layer.alert(resp.msg);
        }
    })
}

//判断禁用启用
function doOpenClose(index,id) {
    if (index == 1) {
        if (confirm("是否禁用")) {
            status(0, id) //这个是方法
        }
    } else {
        if (confirm("是否启用")) {
            status(1, id)
        }
    }
}

function status(index,id){
    $.ajax({
        url: './doOpenClose.do',
        type: 'POST',
        dataType: 'JSON',
        data: {
            action:'doOpenClose',
            status:index,
            id:id
        },
        success: function (resp) {
            console.log(resp);
            if (resp.id == 0){
                layer.alert('修改状态成功');
                getList();
            }
        },
        error: function (resp) {
            layer.alert('修改状态失败');
        }
    })
}


//打开新增面板
function showAddPanel(){
    $('#myModal').modal({
        backdrop: 'static', //背景遮罩
        position: 'fit', //最佳位置
        moveable: true, //可移动的
        rememberPos:true, //记住上次的位置
        scrollInside: true //是否在对话框内部显示滚动条
    })
}
//新增
function createAdmin() {
    var data = {
        account: val('newAccount'),
        password:val('newPassword'),
        role:val('newRole'),
        action: 'docreateAdmin'
    }
    console.log(data);
    $.ajax({
        url: './docreateAdmin.do',
        type: 'POST',
        dataType: 'JSON',
        data: data,
        success: function (resp) {
            layer.alert(resp.msg)
            hideModel();
            getList();
        },
        error: function (resp) {
            layer.alert(resp.msg);
        }
    })
}
//关闭遮罩
function hideModel() {
    $('#myModal').modal('hide', 'fit')
}
