//初始化分页数据变量
var start = 0;
var end = 1;
var limit = 5;
var currPage = 1; //当前页
var allPage = 1;//总页数
var count = 0;
//初始化搜索数据变量
var schName = '';
var schStime = '';
var schEtime = '';
var schStatus = 0;


getList();

//打印admin信息+多条件查询
function getList() {
    $.ajax({
        url: './AdminFileAction.do',
        type: 'GET',
        data: {
            start: start,
            end: limit,
            schName: schName,
            schStatus: schStatus,
            schStime: schStime,
            schEtime: schEtime

        },
        dataType: 'JSON',
        success: function (resp) {
            console.log(resp);
            var fileInfo = resp.datas.fileInfos;
            count = resp.datas.counts;
            if (fileInfo == null || fileInfo.length == 0) {
                currPage = 0;
                allPage = 0;
                layer.alert("暂无数据");
                document.getElementById('fileDatas').innerHTML = '';
            } else {
                var str = '';
                for (var i = 0; i < fileInfo.length; i++) {
                    str += `
                     <tr>
                        <td>${fileInfo[i].fileName}</td>
                        <td>${fileInfo[i].fileSize}</td>
                        <td>${fileInfo[i].fileDate}</td>
                        <td>${fileInfo[i].fileTypeName}</td>
                        <td>${fileInfo[i].fileScore}</td>
                        <td>${fileInfo[i].fileName}</td>
                        <td>${fileInfo[i].fileCustomerName}</td>
                        <td>${fileInfo[i].fileStatus == 0 ? '未审核' : (fileInfo[i].fileStatus == 1 ? '审核通过' : '不通过')}</td>
                           <td>`;
                        if (fileInfo[i].fileStatus == 0) {
                            str += `<button class="btn btn-mini" type="button" onclick="doFileOK(${fileInfo[i].fileStatus},${fileInfo[i].id},${fileInfo[i].customsId})">审核通过</button>
                                    <button class="btn btn-mini" type="button" onclick="doPassFile(${fileInfo[i].fileStatus},${fileInfo[i].id})">不通过</button>
                                    <button class="btn btn-mini" type="button" onclick="dowmLoadFile(${fileInfo[i].id})">下载文件</button>`
                        }
                    str += `
                        </td>
            </tr>`;
                }
                document.getElementById('fileDatas').innerHTML = str;

                //初始化分页数据
                allPage = count % limit == 0 ? (count / limit) : parseInt(count / limit + 1);
                document.getElementById('pageNum').innerHTML = currPage + "/" + allPage;

            }
        },
        error: function (resp) {
            layer.alert("请联系管理员")
        }
    })
}


//上一页
function prevPage() {
    if (currPage == 1) {
        layer.alert("已经是第一页了。")
    } else {
        currPage--;
        start -= limit;
        end -= limit;
        getList();
    }
}

//下一页
function nextPage() {
    if (currPage == allPage) {
        layer.alert("没有下一页了。")
    } else {
        currPage++;
        start += limit;
        end += limit;
        getList();
    }
}

//搜索
function doSearch() {
    start = 0;
    end = 1;
    limit = 3;
    currPage = 1; //当前页
    allPage = 1;//总页数
    count = 0;
//初始化搜索数据变量
    schName = document.getElementById('fileName').value;
    schStime = document.getElementById('sTime').value;
    schEtime = document.getElementById('eTime').value;
    schStatus = document.getElementById('fileStatus').value;
    getList();
}

//审核通过
function doFileOK(status,id,customsId) {
    $.ajax({
        url: './doFileOK.do',
        type: 'POST',
        dataType: 'JSON',
        data: {
            status:1,
            id,
            customsId
        },
        success: function (resp) {
            console.log(resp);
            layer.alert(resp.msg);
            getList();
        },
        error: function (resp) {
            layer.alert(resp.msg);
        }
    })
}

function doPassFile(status,id) {
    $.ajax({
        url: './doPassFile.do',
        type: 'POST',
        dataType: 'JSON',
        data: {
            status:2,
            id,
        },
        success: function (resp) {
            console.log(resp);
            layer.alert(resp.msg);
            getList();
        },
        error: function (resp) {
            layer.alert(resp.msg);
        }
    })

}
//管理员下载
function dowmLoadFile(id) {
    alert(1);
    data={
        id:id
    }
    $.ajax({
        url:'./adminDowmLoadFile.do',
        type:'POST',
        dataType:'JSON',
        data:data,
        success:function (resp) {
            console.log(resp)
            if (resp.id==0){
                window.location.href = "fileDowmload.do";
            }
        },
        error:function (resp) {
            layer.alert("请联系管理员")
        }

    })


}