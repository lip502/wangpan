//初始化分页数据变量
var start = 0;
var end =1;
var limit = 3;
var currPage = 1; //当前页
var allPage = 1;//总页数
var count = 0;
//初始化搜索数据变量
var fileName = '';
var sScore = '';
var eScore = '';
//角色信息的全局
var fileType = null;
getList();
function getList() {
    $.ajax({
        url: './initFile.do',
        type: 'GET',
        data:{
            start:start,
            end:limit,
            fileName:fileName,
            sScore:sScore,
            eScore:eScore

        },
        dataType: 'JSON',
        success: function (resp) {
            console.log(resp);
            fileType = resp.datas.fileType;
            count = resp.datas.counts;
            if (fileType == null || fileType.length == 0){
                currPage = 0;
                allPage = 0;
                layer.alert("暂无数据");
                document.getElementById('fileDatas').innerHTML = '';
            }else {
                var str = '';
                for (var i = 0;i<fileType.length;i++){
                    str +=`
                     <tr>
                        <td>${fileType[i].typeName}</td>
                        <td>${fileType[i].typeLastName}</td>
                        <td>${fileType[i].downloadScore}</td>
                        <td>${fileType[i].typeDate}</td>
                        <td>
                            <button class="btn btn-mini" type="button" onclick="doDelete(${fileType[i].id})">删除</button>
                            <button class="btn btn-mini" type="button" onclick="showupdatePanel(${i})">修改</button>
                        </td>
            </tr>`;
                }
                document.getElementById('fileDatas').innerHTML = str;

                //初始化分页数据
                allPage = count%limit ==0?(count/limit):parseInt(count/limit+1);
                document.getElementById('pageNum').innerHTML = currPage+"/"+allPage;

            }
        },
        error: function (resp) {
            layer.alert("请联系管理员")
        }
    })
}


//上一页
function prevPage() {
    if (currPage == 1){
        layer.alert("已经是第一页了。")
    }else {
        currPage--;
        start -=limit;
        end-=limit;
        getList();
    }
}
//下一页
function nextPage() {
    if (currPage == allPage){
        layer.alert("没有下一页了。")
    }else {
        currPage++;
        start +=limit;
        end+=limit;
        getList();
    }
}
//搜索
function doSearch() {
    start = 0;
    end =1;
    limit = 3;
    currPage = 1; //当前页
    allPage = 1;//总页数
    count = 0;
//初始化搜索数据变量
    fileName = document.getElementById('fileName').value;
    sScore = document.getElementById('sScore').value;
    eScore = document.getElementById('eScore').value;
    getList();
}
//删除
function doDelete(id) {
    $.ajax({
        url: './doDeleteFile.do',
        type: 'POST',
        data:{
           id:id,
            action:'doDelete'
        },
        dataType: 'JSON',
        success: function (resp) {
            layer.alert(resp.msg);
            getList();
        },
        error: function (resp) {
            layer.alert("删除失败")
        }
    })
}
//新增
function showAddPanel() {
    $('#createInfo').modal({
        backdrop: 'static', //背景遮罩
        position: 'fit', //最佳位置
        moveable: true, //可移动的
        rememberPos:true, //记住上次的位置
        scrollInside: true //是否在对话框内部显示滚动条
    })
}

//关闭遮罩
function hidecreateModel() {
    $('#createInfo').modal('hide', 'fit')
}
//新增方法
function docreateInfo() {
    var data = {
        createType:val('createType'),
        createName: val('createName'),
        createScore:val('createScore'),
        action: 'doCreateFileType'
    }
    console.log(data);
    $.ajax({
        url: './docreateFile.do',
        type: 'POST',
        dataType: 'JSON',
        data: data,
        success: function (resp) {
            layer.alert(resp.msg)
            hidecreateModel();
            getList();
        },
        error: function (resp) {
            layer.alert(resp.msg);
        }
    })
}


//打开修改遮罩
function showupdatePanel(index) {
    var file = fileType[index];
    document.getElementById('updateType').value = file.typeName;
    document.getElementById('updateName').value = file.typeLastName;
    document.getElementById('updateScore').value = file.downloadScore;
    document.getElementById('updateId').value = file.id;
    $('#updateInfo').modal({
        backdrop: 'static', //背景遮罩
        position: 'fit', //最佳位置
        moveable: true, //可移动的
        rememberPos:true, //记住上次的位置
        scrollInside: true //是否在对话框内部显示滚动条
    })

}
//关闭遮罩
function hideEditModel() {
    $('#updateInfo').modal('hide', 'fit')
}
//修改管理员信息
function doupdateInfo() {
    var updateType = document.getElementById('updateType').value;
    var updateName = document.getElementById('updateName').value;
    var updateScore = document.getElementById('updateScore').value;
    var updateId = document.getElementById('updateId').value;
    $.ajax({
        url: './doupdateFile.do',
        type: 'POST',
        data:{
            action:'doupdateInfo',
            updateType,updateName,updateScore,updateId
        },
        dataType: 'JSON',
        success: function (resp) {
            layer.alert(resp.msg);
            if (resp.id == 0){
                layer.alert("修改成功")
                hideEditModel();
            }
            getList();
        },
        error: function (resp) {
            layer.alert("请联系管理员")
        }
    })
}
