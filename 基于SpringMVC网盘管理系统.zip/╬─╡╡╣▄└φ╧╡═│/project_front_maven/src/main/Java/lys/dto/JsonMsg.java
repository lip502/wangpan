package lys.dto;
import java.util.HashMap;
import java.util.Map;
    //创建dto传输对象
public class JsonMsg {
    //判断是否成功
    private  Integer id;
    //消息
    private  String msg;
    //跳转的页面
    private  String location;
    //如果需要分页，就使用这个对象存放数据
    private Map<String,Object> datas = new HashMap<>();

    public JsonMsg() {
    }

    public JsonMsg(Integer id, String msg, String location, Map<String, Object> datas) {
        this.id = id;
        this.msg = msg;
        this.location = location;
        this.datas = datas;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Map<String, Object> getDatas() {
        return datas;
    }

    public void setDatas(Map<String, Object> datas) {
        this.datas = datas;
    }
}
