package lys.service;

public interface UserLogInfo {
    Integer selectByFiledowmloadNum(long id);
}
