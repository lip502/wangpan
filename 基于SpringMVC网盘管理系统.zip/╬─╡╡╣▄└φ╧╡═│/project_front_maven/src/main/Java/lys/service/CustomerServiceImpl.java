package lys.service;
import lys.mapper.CustomerMapper;
import lys.pojo.Customer;
import lys.util.SqlSessionUtil;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

@Service
@Transactional(rollbackFor = Exception.class)
public class CustomerServiceImpl implements CustomerService{
    @Resource
    private CustomerMapper customerMapper; // 这里的Mapper就是Spring负责扫描到实例化出来的Mapper对象
    //注册
    @Override
    public int register(Customer customer) {
//        SqlSession session =  SqlSessionUtil.getSqlSession(); //util中获得session
//        CustomerMapper customerMapper = session.getMapper(CustomerMapper.class);
//        int index = customerMapper.create(customer);
//        session.commit();
//        session.close();
        return customerMapper.create(customer);
    }
    //登陆
    @Override
    public Customer Login(String name, String pwd) {
//        SqlSession session =  SqlSessionUtil.getSqlSession(); //util中获得session
//        CustomerMapper customerMapper = session.getMapper(CustomerMapper.class);
//        Customer customer = customerMapper.selectByNameAndPsd(name,pwd);
//        System.out.println("11.1"+customer);
//        session.commit();
//        session.close();
        return customerMapper.selectByNameAndPsd(name,pwd);
    }
    //查询个人信息
    @Override
    public Customer selectCustomerInfo(long id) {
//        SqlSession session =  SqlSessionUtil.getSqlSession(); //util中获得session
//        CustomerMapper customerMapper = session.getMapper(CustomerMapper.class);
//        Customer customer = customerMapper.selectCustomerInfo(id);
//        session.commit();
//        session.close();
        return customerMapper.selectCustomerInfo(id);
    }

    //首页根据用户id查用户名称
    @Override
    public String doNameById(Integer customsId) {
//        SqlSession session =  SqlSessionUtil.getSqlSession(); //util中获得session
//        CustomerMapper customerMapper = session.getMapper(CustomerMapper.class);
//        String customerName = customerMapper.selectByCustomerId(customsId);
//        session.commit();
//        session.close();
        return customerMapper.selectByCustomerId(customsId);
    }
}
