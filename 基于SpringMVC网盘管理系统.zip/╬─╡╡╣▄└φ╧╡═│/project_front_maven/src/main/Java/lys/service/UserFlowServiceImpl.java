package lys.service;
import lys.mapper.UserFlowMapper;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;

@Service
public class UserFlowServiceImpl implements UserFlowService{
    @Resource
    private UserFlowMapper userFlowMapper;

    @Override
    public Integer selectUserDowmloadNum(long id) {
        return userFlowMapper.selectUserDowmloadNum(id);
    }

    @Override
    public Integer selectUseruploadNum(long id) {
        return userFlowMapper.selectUseruploadNum(id);
    }
}
