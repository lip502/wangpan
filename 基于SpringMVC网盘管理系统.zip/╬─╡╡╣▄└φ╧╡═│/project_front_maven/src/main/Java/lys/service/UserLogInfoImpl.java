package lys.service;
import lys.mapper.UserLogMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class UserLogInfoImpl implements UserLogInfo{
    @Resource
    private UserLogMapper userLogMapper;
    @Override
    public Integer selectByFiledowmloadNum(long id) {

        return userLogMapper.selectByFiledowmloadNum(id);
    }
}
