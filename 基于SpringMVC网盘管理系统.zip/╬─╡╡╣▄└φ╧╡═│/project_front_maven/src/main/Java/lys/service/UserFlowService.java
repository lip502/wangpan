package lys.service;

public interface UserFlowService {
    Integer selectUserDowmloadNum(long id);

    Integer selectUseruploadNum(long id);
}
