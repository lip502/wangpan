package lys.service;
import lys.dto.JsonMsg;
import lys.mapper.CustomerMapper;
import lys.mapper.FileMapper;
import lys.mapper.UserFlowMapper;
import lys.mapper.UserLogMapper;
import lys.pojo.Customer;
import lys.pojo.File;
import lys.pojo.UserFlow;
import lys.pojo.UserLog;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.Resource;
import java.util.List;
@Service
@Transactional(rollbackFor = Exception.class)
public class FileServiceImpl implements FileService{
    @Resource
    private FileMapper fileMapper; // 这里的Mapper就是Spring负责扫描到实例化出来的Mapper对象
    @Resource
    private UserLogMapper userLogMapper;
    @Resource
    private CustomerMapper customerMapper;
    @Resource
    private UserFlowMapper userFlowMapper;
    //我的文檔
    @Override
    public List<File> quenyByPage(long id, String fileName, String sTime, String eTime, String start, String end) {
        //非空判断
        if (fileName.equals("")){
            fileName = null;
        }
        if (sTime.equals("")){
            sTime = null;
        }
        if (eTime.equals("")){
            eTime = null;
        }

        return fileMapper.selectByPage(id,fileName,sTime,eTime,new RowBounds(Integer.parseInt(start),Integer.parseInt(end)));
    }


    @Override
    public Integer countByPage(long id,String fileName, String sTime, String eTime) {
        //非空判断
        if (fileName.equals("")){
            fileName = null;
        }
        if (sTime.equals("")){
            sTime = null;
        }
        if (eTime.equals("")){
            eTime = null;
        }
        return fileMapper.countByPage(id,fileName,sTime,eTime);

    }


    @Override
    public List<File> shouyeQuenyByPage(String fileName, String sTime, String eTime, String start, String end) {
        //非空判断
        if (fileName.equals("")){
            fileName = null;
        }
        if (sTime.equals("")){
            sTime = null;
        }
        if (eTime.equals("")){
            eTime = null;
        }
//
        return fileMapper.shouyeQuenyByPage(fileName,sTime,eTime,
                new RowBounds(Integer.parseInt(start),Integer.parseInt(end)));
    }

//    @Override
    public Integer shouyeCountByPage(String fileName, String sTime, String eTime) {
        //非空判断
        if (fileName.equals("")){
            fileName = null;
        }
        if (sTime.equals("")){
            sTime = null;
        }
        if (eTime.equals("")){
            eTime = null;
        }
        return fileMapper.shouyeCountByPage(fileName,sTime,eTime);
    }

    //用户新增文档信息
    @Override
    public Integer createFileByCustomer(File file,String fileType) {
        Integer index =fileMapper.createFileByCustomer(file,fileType);
        //添加日志
        UserLog userLog = new UserLog();
        userLog.setUserId(file.getCustomsId());
        userLog.setContend("上传文件"+file.getFileName());
        index = userLogMapper.insertUserLog(userLog);
        return index;
    }


    //用户下载事务
    @Override
    public JsonMsg selectFileInfoById(Customer customer, int iId) {
        JsonMsg msg = new JsonMsg();
        //判断下载文件是不是用户自己的文件 是？‘不扣分’：‘扣分并添加日志’
        File file = fileMapper.selectByFileId(iId); //获得文件id对应的用户id
        Integer index =-1;
        //如下载文件不是自己的情况下
        if (customer.getId() != file.getCustomsId()){
            //如果积分足够
            if (customer.getScore()>file.getFileScore()){
                //用户积分扣除并添加到日志
               index =   customerMapper.updateCustomerScore(customer.getId(),-file.getFileScore());
             if (index <= 0){
                 msg.setId(1);
                 msg.setMsg("扣除积分失败");
                 return msg;
             }
                //添加用户下载日志
                UserLog userLog = new UserLog();
                userLog.setContend("下载");
                userLog.setUserId((int) customer.getId());
                userLog.setFileId(iId);
                index = userLogMapper.createCustomerDowmloadLog(userLog);
                if (index<=0){
                    msg.setId(1);
                    msg.setMsg("添加日志失败");
                    return msg;
                }

                //添加文件上传用户文件的下载的流水信息
                UserFlow userFlow = new UserFlow();
                userFlow.setUserId(file.getCustomsId());
                userFlow.setScoreStatus(2);
                userFlow.setScore(file.getFileScore());
                System.err.println(userFlow);
                index = userFlowMapper.createCustomerFlow(userFlow);
                if (index<=0){
                    msg.setId(1);
                    msg.setMsg("添加积分流水失败");
                    return msg;
                }
                //添加下载用户文件的下载的流水信息
                UserFlow userFlow1 = new UserFlow();
                userFlow1.setUserId(customer.getId());
                userFlow1.setScoreStatus(2);
                userFlow1.setScore(file.getFileScore());
                index = userFlowMapper.createCustomerFlow(userFlow1);
                if (index<=0){
                    msg.setId(1);
                    msg.setMsg("添加积分流水失败");
                    return msg;
                }

                //对应上传文件用户的积分增加
                index =   customerMapper.updateCustomerScore(file.getCustomsId(),file.getFileScore());
                if (index<=0){
                    msg.setId(1);
                    msg.setMsg("上传用户文件者积分增加失败");
                    return msg;
                }
            }
        }
        msg.setId(0);
        msg.getDatas().put("file",file);
        return msg;
    }




}
