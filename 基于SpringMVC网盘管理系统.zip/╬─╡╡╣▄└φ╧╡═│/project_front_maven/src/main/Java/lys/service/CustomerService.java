package lys.service;
import lys.pojo.Customer;

public interface CustomerService {
    int register(Customer customer);

    Customer Login(String name, String pwd);

    Customer selectCustomerInfo(long id);

    String doNameById(Integer customsId);
}
