package lys.service;
import lys.mapper.FileMapper;
import lys.mapper.ScoreFlowMapper;
import lys.pojo.ScoreFlow;
import lys.util.SqlSessionUtil;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
@Service
@Transactional(rollbackFor = Exception.class)
public class ScoreFlowServiceImpl implements ScoreFlowService{
    @Resource
    private ScoreFlowMapper scoreFlowMapper; // 这里的Mapper就是Spring负责扫描到实例化出来的Mapper对象
    @Override
    public List<ScoreFlow> quenyByPage(long id, String sTime, String eTime, String start, String end) {
//        SqlSession session = SqlSessionUtil.getSqlSession();
//        ScoreFlowMapper scoreFlowMapper = session.getMapper(ScoreFlowMapper.class); //拿到adminMapper
        //非空判断
        if (sTime.equals("")) {
            sTime = null;
        }
        if (eTime.equals("")) {
            eTime = null;
        }

//        List<ScoreFlow> scoreFlow = scoreFlowMapper.selectByPage(id, sTime, eTime,
//                new RowBounds(Integer.parseInt(start), Integer.parseInt(end)));
//        session.commit();
//        session.close();
        return scoreFlowMapper.selectByPage(id, sTime, eTime,
                new RowBounds(Integer.parseInt(start), Integer.parseInt(end)));
    }

    @Override
    public Integer countByPage(long id, String sTime, String eTime) {
//        SqlSession session = SqlSessionUtil.getSqlSession();
//        ScoreFlowMapper scoreFlowMapper = session.getMapper(ScoreFlowMapper.class); //拿到adminMapper
        //非空判断
        if (sTime.equals("")) {
            sTime = null;
        }
        if (eTime.equals("")) {
            eTime = null;
        }
//        Integer count = scoreFlowMapper.countByPage(id, sTime, eTime);
//        session.commit();
//        session.close();
        return scoreFlowMapper.countByPage(id, sTime, eTime);
    }
}

