package lys.service;

import lys.pojo.ScoreFlow;

import java.util.List;

public interface ScoreFlowService {
    List<ScoreFlow> quenyByPage(long id, String sTime, String eTime, String start, String end);

    Integer countByPage(long id, String sTime, String eTime);
}
