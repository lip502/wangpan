package lys.service;

import lys.dto.JsonMsg;
import lys.pojo.Customer;
import lys.pojo.File;

import java.util.List;

public interface FileService {

    Integer countByPage(long id, String fileName, String sTime, String eTime);

    List<File> quenyByPage(long id, String fileName, String sTime, String eTime, String start, String end);

    List<File> shouyeQuenyByPage(String fileName, String sTime, String eTime, String start, String end);

    Integer shouyeCountByPage(String fileName, String sTime, String eTime);

    Integer createFileByCustomer(File file,String fileType);

    JsonMsg selectFileInfoById(Customer customer, int iId);
}
