package lys.util;

import com.alibaba.fastjson.JSONObject;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;

public class Ajax {
	public static void error(HttpServletResponse resp , String errmsg ,  int errcode ) {
		HashMap<String,Object >map = new HashMap<String, Object>();
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		map.put("errcode",	errcode);
		map.put("errmsg",errmsg);
		try {
			resp.getWriter().println( JSONObject.toJSON(map));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return;
	}
	
	public static void error(HttpServletResponse resp , String errmsg ) {
		error(resp,errmsg,10000);
	}
	
	
	public static void success(HttpServletResponse resp) {
		HashMap<String,Object >map = new HashMap<String, Object>();
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		map.put("success",	true);
		try {
			resp.getWriter().println( JSONObject.toJSON(map));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return;
	}
	
	public static void success(HttpServletResponse resp , String key , Object value) {
		HashMap<String,Object >map = new HashMap<String, Object>();
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		map.put("success",	true);
		
		if(null != key &&  null != value) {
			map.put(key,	value);
		}
		
		try {
			resp.getWriter().println( JSONObject.toJSON(map));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return;
	}

	public static void success(HttpServletResponse resp, HashMap<String, Object> map) {
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		map.put("success",	true);

		try {
			resp.getWriter().println( JSONObject.toJSON(map));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return;
	}

}
