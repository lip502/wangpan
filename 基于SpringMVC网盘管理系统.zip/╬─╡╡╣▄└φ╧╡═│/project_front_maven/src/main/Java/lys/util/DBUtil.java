package lys.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
	// 定义属性
	private static String driver;
	private static String url;
	private static String userName;
	private static String passWord;

	// 静态快
	static {
		Properties p = new Properties();
		try {
			String path = URLDecoder.decode(DBUtil.class.getClassLoader().getResource("").getPath());
			path += "dbconfig.properties";
			p.load(new FileInputStream(new File(path)));
			driver = p.getProperty("driver");
			url = p.getProperty("url");
			userName = p.getProperty("userName");
			passWord = p.getProperty("passWord");

			Class.forName(driver);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	// 公有的连接方法
	public static Connection getConn() {
		try {
			Connection conn = DriverManager.getConnection(url, userName, passWord);
			if (conn != null) {
				System.out.println("数据库连接成功！");
				return conn;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("数据库连接失败！");
		return null;
	}

	// 关闭连接的方法
	public static void close(Connection conn, PreparedStatement psmt, ResultSet rs) {
		try {
			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//单关闭连接的方法
	public static void close(Connection conn) {
		close(conn, null, null);
	}

	
}
