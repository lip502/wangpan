package lys.util;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;

public class SqlSessionUtil {


    private static SqlSessionFactory sqlSessionFactory;
    static {
        try {
            // 1. 获取xml配置文件的路径
            String resource = "mybatis-config.xml";
            // 2. 获取配置文件流
            InputStream inputStream = Resources.getResourceAsStream(resource);
            // 3. 通过加载配置文件的流 得到SqlSessionFactory 工厂
            sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static SqlSession getSqlSession() {
        return sqlSessionFactory.openSession();
    }
}
