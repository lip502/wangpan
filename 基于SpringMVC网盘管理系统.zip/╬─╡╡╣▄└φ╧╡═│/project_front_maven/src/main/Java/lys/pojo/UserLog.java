package lys.pojo;

import java.sql.Date;

public class UserLog {
    private Integer id;
    private Integer userId;
    private String contend;
    private Date doDate;
    private Integer fileId;

    public UserLog() {
    }

    public UserLog(Integer id, Integer userId, String contend, Date doDate, Integer fileId) {
        this.id = id;
        this.userId = userId;
        this.contend = contend;
        this.doDate = doDate;
        this.fileId = fileId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getContend() {
        return contend;
    }

    public void setContend(String contend) {
        this.contend = contend;
    }

    public Date getDoDate() {
        return doDate;
    }

    public void setDoDate(Date doDate) {
        this.doDate = doDate;
    }

    public Integer getFileId() {
        return fileId;
    }

    public void setFileId(Integer fileId) {
        this.fileId = fileId;
    }
}
