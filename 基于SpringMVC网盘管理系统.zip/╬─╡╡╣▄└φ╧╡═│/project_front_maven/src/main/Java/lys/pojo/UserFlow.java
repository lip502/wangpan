package lys.pojo;

import java.sql.Date;

public class UserFlow {

    private long id;
    private long userId;
    private Integer scoreStatus;
    private Integer score;
    private Date regDate;

    public UserFlow() {
    }

    public UserFlow(long id, long userId, Integer scoreStatus, Integer score, Date regDate) {
        this.id = id;
        this.userId = userId;
        this.scoreStatus = scoreStatus;
        this.score = score;
        this.regDate = regDate;
    }

    @Override
    public String toString() {
        return "UserFlow{" +
                "id=" + id +
                ", userId=" + userId +
                ", scoreStatus=" + scoreStatus +
                ", score=" + score +
                ", regDate=" + regDate +
                '}';
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public Integer getScoreStatus() {
        return scoreStatus;
    }

    public void setScoreStatus(Integer scoreStatus) {
        this.scoreStatus = scoreStatus;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Date getRegDate() {
        return regDate;
    }

    public void setRegDate(Date regDate) {
        this.regDate = regDate;
    }
}
