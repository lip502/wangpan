package lys.pojo;

import java.sql.Date;

public class FileType {
    private long id;
    private String typeName;
    private String typeLastName;
    private long dowmloadScore;
    private Date typeDate;

    public FileType() {
    }

    public FileType(long id, String typeName, String typeLastName, long dowmloadScore, Date typeDate) {
        this.id = id;
        this.typeName = typeName;
        this.typeLastName = typeLastName;
        this.dowmloadScore = dowmloadScore;
        this.typeDate = typeDate;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getTypeLastName() {
        return typeLastName;
    }

    public void setTypeLastName(String typeLastName) {
        this.typeLastName = typeLastName;
    }

    public long getDowmloadScore() {
        return dowmloadScore;
    }

    public void setDowmloadScore(long dowmloadScore) {
        this.dowmloadScore = dowmloadScore;
    }

    public Date getTypeDate() {
        return typeDate;
    }

    public void setTypeDate(Date typeDate) {
        this.typeDate = typeDate;
    }
}
