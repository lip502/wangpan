package lys.mapper;

import lys.pojo.UserFlow;
import org.apache.ibatis.annotations.Param;

public interface UserFlowMapper {
    Integer selectUserDowmloadNum(@Param("iId") long id);

    Integer selectUseruploadNum(@Param("iId") long id);

    Integer createCustomerFlow(@Param("userFlow") UserFlow userFlow);
}
