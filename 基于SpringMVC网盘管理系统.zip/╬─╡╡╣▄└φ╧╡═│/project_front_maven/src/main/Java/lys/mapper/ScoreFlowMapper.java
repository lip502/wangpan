package lys.mapper;
import lys.pojo.ScoreFlow;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import java.util.List;

public interface ScoreFlowMapper {
    List<ScoreFlow> selectByPage(@Param("id") long id, @Param("sTime")String sTime,@Param("eTime") String eTime, RowBounds rowBounds);

    Integer countByPage(@Param("id")long id,@Param("sTime") String sTime,@Param("eTime") String eTime);
}
