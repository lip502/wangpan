package lys.mapper;
import lys.pojo.Customer;
import org.apache.ibatis.annotations.Param;

public interface CustomerMapper {
    //注册用户
    int create(@Param("c") Customer customer);
    //登陆
    Customer selectByNameAndPsd(@Param("name") String name, @Param("pwd") String pwd);

    Customer selectCustomerInfo(@Param("customerId") long id);

    String selectByCustomerId(@Param("customsId") Integer customsId);

    Integer updateCustomerScore(@Param("id") long id,@Param("fileScore") Integer fileScore);



}
