package lys.mapper;

import lys.pojo.UserLog;
import org.apache.ibatis.annotations.Param;

public interface UserLogMapper {
    Integer insertUserLog(@Param("userLog") UserLog userLog);
    //下载文件添加日志
    Integer createCustomerDowmloadLog(@Param("userLog") UserLog userLog);

    Integer selectByFiledowmloadNum(@Param("id") long id);

    Integer selectUserDowmloadNum(@Param("id") long id);
}
