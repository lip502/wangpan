package lys.mapper;

import org.apache.ibatis.annotations.Param;

public interface FileTypeMapper {
    String doFileTypeName(@Param("fileStype") Integer fileStyle);
}
