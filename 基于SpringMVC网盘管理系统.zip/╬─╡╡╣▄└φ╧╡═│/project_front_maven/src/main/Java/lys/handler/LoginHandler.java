package lys.handler;
import lys.dto.JsonMsg;
import lys.pojo.Customer;
import lys.service.CustomerService;
import lys.util.Captcha;
import lys.util.RSAUtils;
import org.springframework.util.Base64Utils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

@RestController
public class LoginHandler {
    @Resource
    private CustomerService customerService;
    //获得公钥和私钥的键值对
    Map<String, Object> keyMap = RSAUtils.genKeyPair();

    public LoginHandler() throws NoSuchAlgorithmException {
    }

    @PostMapping("/doLogin.do")
    public JsonMsg doLogin(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        String name = req.getParameter("name");
        String pwd = req.getParameter("pwd");
        String code = req.getParameter("code");

        String privateKey = RSAUtils.getPrivateKey(keyMap);
        byte[] decryptByPrivateKey = RSAUtils.decryptByPrivateKey(Base64Utils.decode(pwd.replaceAll("%2B", "+").getBytes()), privateKey);
        String password = new String(decryptByPrivateKey);

        JsonMsg msg = new JsonMsg();
        String sessionCode = (String) req.getSession().getAttribute("captchaCode");
        if (null == code || !code.equalsIgnoreCase(sessionCode)) {
            msg.setId(1);
            msg.setMsg("验证码错误，请重新输入");
            return msg;
        }
        Customer customer = customerService.Login(name,password);
        if(customer != null) {
            req.getSession().setAttribute("customer", customer);
            msg.setId(0);
            msg.setMsg("登录成功...");
            msg.setLocation("home_front");
        }else {
            msg.setId(1);
            msg.setMsg("登录失败，用户名或密码错误");
        }
        return msg;
    }

    @PostMapping("doRegister.do")
    public JsonMsg doRegister(HttpServletRequest req, HttpServletResponse resp){
        JsonMsg msg = new JsonMsg();
        String account = req.getParameter("account");
        String password = req.getParameter("password");
        String userName = req.getParameter("userName");
        String sex = req.getParameter("sex");
        String phone = req.getParameter("phone");
        String education = req.getParameter("education");
        String work = req.getParameter("work");
        String email = req.getParameter("email");
        int iSex = -1;
        try {
            iSex = Integer.parseInt(sex);
        } catch (NumberFormatException e) {
            msg.setMsg("性别错误");
            return null;
        }
//        CustomerService customerService = ServiceFactory.newInstance().getServiceObj(CustomerService.class);
        Customer customer = new Customer(0L,account,userName,password,null,
                1,iSex,education,work,email,phone,0L);
        int index = customerService.register(customer);
        if (index != 0){
            msg.setId(0);
            msg.setMsg("注册成功！");
            msg.setLocation("login_front");
        }else{
            msg.setId(1);
            msg.setMsg("注册失败");
        }
//        response.getWriter().println(JSONObject.toJSONString(msg));
        return msg;
    }

    //显示名字
    @GetMapping("doUserName.do")
    protected JsonMsg doUserName(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 显示名字
        JsonMsg msg = new JsonMsg();
        Customer customer = (Customer) req.getSession().getAttribute("customer");
        msg.getDatas().put("customer", customer);
//        resp.getWriter().println(JSONObject.toJSONString(msg));
        return msg;
    }
    //验证码
    @GetMapping("captcha.do")
    protected void captcha(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Captcha capt = new Captcha();
        BufferedImage img = capt.getImage();
        //响应输出流
        String code = capt.getCode();
        //把code存在session里面
        req.getSession().setAttribute("captchaCode", code);
        ServletOutputStream os = resp.getOutputStream();
        ImageIO.write(img, "jpeg", os);


    }

    @GetMapping("rasPublicKey.do")
    public JsonMsg rasPublicKey() {
        JsonMsg msg = new JsonMsg();
        String publicKey = RSAUtils.getPublicKey(keyMap);
        msg.setId(0);
        msg.setMsg(publicKey);
        return msg;
    }


}
