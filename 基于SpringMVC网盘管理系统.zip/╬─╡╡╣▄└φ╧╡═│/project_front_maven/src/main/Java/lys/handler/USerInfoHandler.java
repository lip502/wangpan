package lys.handler;
import lys.dto.JsonMsg;
import lys.mapper.UserLogMapper;
import lys.pojo.Customer;
import lys.service.CustomerService;
import lys.service.UserFlowService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
public class USerInfoHandler {
    @Resource
    private CustomerService customerService;
    @Resource
    private UserFlowService userFlowService;
    @Resource
    private UserLogMapper userLogMapper;
    @GetMapping("gerenxinxi.do")
    protected JsonMsg doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonMsg msg = new JsonMsg();
        Customer customer = (Customer) req.getSession().getAttribute("customer");
        System.err.println(customer.getId());
        //查询用户流水的上传数量和下载数量
        Integer dowmLoadNum = userLogMapper.selectUserDowmloadNum(customer.getId());
        Integer uploadNum = userFlowService.selectUseruploadNum(customer.getId());
        //调用方法
        Customer customerInfo = customerService.selectCustomerInfo(customer.getId());
        if (customerInfo != null){
            msg.setId(0);
            msg.getDatas().put("customerInfo", customerInfo);
            msg.getDatas().put("dowmLoadNum",dowmLoadNum);
            msg.getDatas().put("uploadNum",uploadNum);
        }else{
            msg.setId(1);
            msg.setMsg("查询失败");
        }
        return msg;
    }
}
