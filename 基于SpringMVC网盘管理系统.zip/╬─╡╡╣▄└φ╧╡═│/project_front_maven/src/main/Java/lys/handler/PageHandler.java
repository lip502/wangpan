package lys.handler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
public class PageHandler {
    @GetMapping("page.do")
    public ModelAndView pager(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String p = req.getParameter("p");
        if (p == null || p.equals("")) {
            return new ModelAndView("home_front");
        } else {
            return new ModelAndView(p);
        }

    }

    @GetMapping("doExit.do")
    public void exit(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.getSession().invalidate();
        resp.sendRedirect("page.do");
    }
}
