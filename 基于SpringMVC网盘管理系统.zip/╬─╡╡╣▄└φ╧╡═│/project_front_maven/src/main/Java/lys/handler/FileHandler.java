package lys.handler;
import lys.dto.JsonMsg;
import lys.mapper.FileTypeMapper;
import lys.pojo.Customer;
import lys.pojo.File;
import lys.service.CustomerService;
import lys.service.FileService;
import lys.service.UserLogInfo;
import lys.vo.Flieshouye;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RestController
public class FileHandler {
    @Value("#{config.path}")
    private String str;
    @Resource
    private FileService fileService;
    @Resource
    private CustomerService customerService;
    @Resource
    private FileTypeMapper fileTypeMapper;
    //我的文档管理
    @GetMapping("file.do")
    protected JsonMsg file(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonMsg msg = new JsonMsg();
        String start = req.getParameter("start");
        String end = req.getParameter("end");
        String fileName = req.getParameter("fileName");
        String sTime = req.getParameter("sTime");
        String eTime = req.getParameter("eTime");
        //session拿到用户登陆的id
        Customer customer = (Customer) req.getSession().getAttribute("customer");
        List<File> file =  fileService.quenyByPage(customer.getId(),fileName,sTime,eTime,start,end);
        Integer count = fileService.countByPage(customer.getId(),fileName,sTime,eTime);
        //发送给前端
        msg.getDatas().put("file", file);
        msg.getDatas().put("counts", count);
        return msg;
    }

    @Resource
    private UserLogInfo userLogInfo;
    //首页文档管理
    @GetMapping("shouyefile.do")
    protected JsonMsg shouyefile(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonMsg msg = new JsonMsg();
        String start = req.getParameter("start");
        String end = req.getParameter("end");
        String fileName = req.getParameter("fileName");
        String sTime = req.getParameter("sTime");
        String eTime = req.getParameter("eTime");

        List<File> file =  fileService.shouyeQuenyByPage(fileName,sTime,eTime,start,end);
        List<Flieshouye> fileshouye = new ArrayList<>();
        for(int i = 0;i<file.size();i++){
            String name =customerService.doNameById(file.get(i).getCustomsId());//查用户名字
            String fileTypeName = fileTypeMapper.doFileTypeName(file.get(i).getFileStyle());//查类型名字
//          //查询文件下载量（根据用户日志表）
//          Integer fileDownloadNum = userLogInfo.selectByFiledowmloadNum(file.get(i).getId());
            Flieshouye filesy = new Flieshouye();
            filesy.setId(file.get(i).getId());
            System.err.println("haha"+filesy.getId());
            //查询文件下载量（根据用户日志表）
            Integer fileDownloadNum = userLogInfo.selectByFiledowmloadNum(file.get(i).getId());
            //System.err.println("haha"+fileDownloadNum);
            filesy.setFileName(file.get(i).getFileName());
            filesy.setFileSize(file.get(i).getFileSize());
            filesy.setFileDate(file.get(i).getFileDate());
            filesy.setUserName(name);
            filesy.setFileTypeName(fileTypeName);
            filesy.setFileScore(file.get(i).getFileScore());
            filesy.setDowmloadNum(fileDownloadNum);
            fileshouye.add(filesy);
        }
        Integer count = fileService.shouyeCountByPage(fileName,sTime,eTime);

        //发送给前端
        msg.getDatas().put("file", fileshouye);
        msg.getDatas().put("counts", count);
        return msg;
    }

    //用户新增文件
    @PostMapping("docommitFile.do")
    public JsonMsg docommitFile(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonMsg msg = new JsonMsg();
        String fileName = req.getParameter("fileName");
        String fileType = req.getParameter("fileType");
        String fileSize = req.getParameter("fileSize");
        String fileScore = req.getParameter("fileScore");
        System.err.println("11.14 10点加文件类型"+fileType);

        int iFileSize = -1;
        try {
            iFileSize = Integer.parseInt(fileSize);
        } catch (NumberFormatException e) {
            msg.setMsg("文件大小出错");
            return msg;
        }
        int iFileScore = -1;
        try {
            iFileScore = Integer.parseInt(fileScore);
        } catch (NumberFormatException e) {
            msg.setMsg("文件积分出错");
            return msg;
        }
        Customer customer = (Customer) req.getSession().getAttribute("customer");
        File file = new File();
        file.setCustomsId((int) customer.getId());
        file.setFileName(fileName);
        file.setFileSize(iFileSize);
        file.setFileScore(iFileScore);
       Integer index = fileService.createFileByCustomer(file,fileType);
        if (index != null) {
            msg.setMsg("上传文件成功！");
        } else {
            msg.setMsg("上传文件失败！");
        }
        return msg;
    }


    private File file = null;
    //用户下载首页文件
    @PostMapping("dowmLoadFile.do")
    public JsonMsg dowmLoadFile(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonMsg msg = new JsonMsg();
        String id = req.getParameter("id");
        Customer customer  = (Customer) req.getSession().getAttribute("customer");
        int iId = -1;
        try {
            iId = Integer.parseInt(id);
        } catch (NumberFormatException e) {
            msg.setMsg("id出错");
            return msg;
        }
         msg = fileService.selectFileInfoById(customer,iId);
        if (msg.getId() == 0) {
            file = (File) msg.getDatas().get("file");
        }
        return msg;
    }



    //文件下载
    @GetMapping("fileDowmload.do")
    public void download(HttpServletRequest req, HttpServletResponse resp) {
//        String fileName = "文件上传和下载.txt";
//        String path = "C://";
        try {
            // 1.设置输出文件类型，是以流的方式进行输出
            resp.setContentType("application/octet-stream; charset=utf-8");
            // 2.设置该文件用来下载，并且下载的文件名是xxx
            String fileEncode = new String(file.getFileName().getBytes("UTF-8"), "ISO8859-1");
            resp.setHeader("Content-Disposition", "attachment; filename=" + fileEncode);
            // 3.通过IO流将文件写出
            FileUtils.copyFile(new java.io.File(str + file.getFileName()), resp.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }




}
