package lys.handler;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.IOException;

@RestController
public class FileIOHandler {

    @Value("#{config.path}")
    private String str;

    @PostMapping("uploader.do") // 这里一定是POST请求，因为get请求的大小只能是2kb
    public String uploader(MultipartFile file) throws IOException { // 传入参数，而这里的参数的变量名一定要叫做file
//        System.out.println(file.getSize()); // 文件大小
//        System.out.println(file.getOriginalFilename()); // 文件名
//        System.out.println(file.getName()); // 变量名称
//        System.out.println(file.getContentType()); // 文件mimetype类型
//        System.out.println(file.getResource()); // 文件资源信息对象
        // String str = "C://";
        System.out.println("112122:" +str + file.getOriginalFilename());
        FileUtils.copyInputStreamToFile(file.getInputStream(),
                new File(str + file.getOriginalFilename()));
        return "success,上传完成！！";
    }
}
