package lys.handler;
import lys.dto.JsonMsg;
import lys.pojo.Customer;
import lys.pojo.ScoreFlow;
import lys.service.ScoreFlowService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@RestController
public class ScoreFlowHandler {
    @Resource
    private ScoreFlowService scoreFlowService;
    //我的积分流水
    @GetMapping("scoreFlow.do")
    protected JsonMsg scoreFlow(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonMsg msg = new JsonMsg();
        String start = req.getParameter("start");
        String end = req.getParameter("end");
        String sTime = req.getParameter("sTime");
        String eTime = req.getParameter("eTime");

        Customer customer = (Customer) req.getSession().getAttribute("customer");
        List<ScoreFlow> scoreFlow =  scoreFlowService.quenyByPage(customer.getId(),sTime,eTime,start,end);
        Integer count = scoreFlowService.countByPage(customer.getId(),sTime,eTime);

        msg.getDatas().put("scoreFlow", scoreFlow);
        msg.getDatas().put("counts", count);
        return msg;
    }

}
