//初始化分页数据变量
var start = 0;
var end =1;
var limit = 3;
var currPage = 1; //当前页
var allPage = 1;//总页数
var count = 0;
//初始化搜索数据变量
var sTime = '';
var eTime = '';
//角色信息的全局
var scoreFlow = null;
getList();
function getList() {
    $.ajax({
        url: './scoreFlow.do',
        type: 'GET',
        data:{
            start:start,
            end:limit,
            sTime:sTime,
            eTime:eTime
        },
        dataType: 'JSON',
        success: function (resp) {
            console.log(resp);
            scoreFlow = resp.datas.scoreFlow;
            count = resp.datas.counts;
            if (scoreFlow == null || scoreFlow.length == 0){
                currPage = 0;
                allPage = 0;
                layer.alert("暂无数据");
                document.getElementById('fileDatas').innerHTML = '';
            }else {
                var str = '';
                for (var i = 0;i<scoreFlow.length;i++){
                    str += `
                <tr>    
                    <td>${scoreFlow[i].scoreStatus == 1 ? '上传' : '下载'}</td>
                    <td>${scoreFlow[i].score}</td>
                    <td>${scoreFlow[i].regDate}</td>
                        </tr>
                        `;
                }
                document.getElementById('fileDatas').innerHTML = str;

                //初始化分页数据
                allPage = count%limit ==0?(count/limit):parseInt(count/limit+1);
                document.getElementById('pageNum').innerHTML = currPage+"/"+allPage;

            }
        },
        error: function (resp) {
            layer.alert(resp.msg)
        }
    })
}


//上一页
function prevPage() {
    if (currPage == 1){
        layer.alert("已经是第一页了。")
    }else {
        currPage--;
        start -=limit;
        end-=limit;
        getList();
    }
}
//下一页
function nextPage() {
    if (currPage == allPage){
        layer.alert("没有下一页了。")
    }else {
        currPage++;
        start +=limit;
        end+=limit;
        getList();
    }
}
//搜索
function doSearch() {
    start = 0;
    end =1;
    limit = 3;
    currPage = 1; //当前页
    allPage = 1;//总页数
    count = 0;
//初始化搜索数据变量
    sTime = document.getElementById('sTime').value;
    eTime = document.getElementById('eTime').value;
    getList();
}