gerenxinxi();
function gerenxinxi() {

    $.ajax({
        url: './gerenxinxi.do',
        type: 'GET',
        dataType: 'JSON',
        success: function (resp) {
                if (resp.id == 0) {
                    console.log(resp)
                  info =  resp.datas.customerInfo;
                  dowmLoadNum = resp.datas.dowmLoadNum;
                  uploadNum = resp.datas.uploadNum;

                    document.getElementById('account').value = info.account;
                    document.getElementById('userName').value = info.userName;
                    document.getElementById('regDate').value = info.regDate;
                    document.getElementById('sex').value = info.sex;
                    document.getElementById('work').value = info.work;
                    document.getElementById('school').value = info.education;
                    document.getElementById('email').value = info.email;
                    document.getElementById('phone').value = info.phone;
                    document.getElementById('score').value = info.score;
                    document.getElementById('upNumber').value = uploadNum;
                    document.getElementById('dowmNumber').value = dowmLoadNum;
                }

        },
        error: function (resp) {
            layer.closeAll('loading');
           if (resp.id == 1){
               layer.alert(resp.msg);
           }
        }

    })
}