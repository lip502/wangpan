getList();
function getList() {
    $.ajax({
        url: './doUserName.do',
        type: 'GET',
        dataType: 'JSON',
        success: function (resp) {
            console.log(resp);
            customer = resp.datas.customer;
            if (customer == null || customer.length == 0){
                document.getElementById("daohangtiao").innerHTML=`
                    <li><a href="page.do?p=login_front">登陆</a></li>
                    <li><a href="page.do?p=register">注册</a></li>`;
            }else {
                document.getElementById("daohangtiao").innerHTML=`
                    <li><a href="page.do?p=shouye" target="iframe">首页</a></li>
                    <li><a href="page.do?p=register">注册</a></li>
                    <li><a href="page.do?p=gerenxinxi" target="iframe">欢迎：
                    <span id="userName">${customer.userName}</span></a></li>
                    <li><a href="page.do?p=wenjianshangchuan" target="iframe">文档上传</a></li>
                    <li><a href="page.do?p=wodewendang" target="iframe">我的文档</a></li>
                    <li><a href="page.do?p=jifenliushui" target="iframe">积分流水</a></li>
                    <li><a href="###" onclick="doExit()">注销</a></li>
                `

            }
        },
        error: function (resp) {
            layer.alert("请联系管理员")
        }
    })
}

function doExit() {
    layer.confirm("你确定退出吗？",{
        btn:['确定']
    },function() {
        window.location.href="doExit.do";
    });
}
