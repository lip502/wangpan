function registerOK() {
    layer.load(2);
    //效验 待做
    var data = {
        account:val('account'),
        password: val('password').trim(),
        userName: val('userName').trim(),
        sex:radioVal('radioOptionsExample'),
        education:val('education'),
        work:val('work'),
        phone:val('phone'),
        email:val('email'),
        action: 'getRegister'
    }
    console.log(data);
    $.ajax({
        url: './doRegister.do',  //要把数据提交到哪里去  等同于 form 的action属性
        type: 'POST',  //要以什么方式去请求 get post
        dataType: 'JSON', //以什么格式来解析返回回来的数据
        data: data, //要提交什么数据到 Servlet去。
        success: function (resp) {
            layer.closeAll('loading');
            layer.alert(resp.msg, {
                closeBtn: 0
            }, function () {
                if (resp.id == 0) {
                    window.location.href = 'page.do?p=' + resp.location;
                }
            });
        },
        error: function (resp) {
            layer.closeAll('loading');
            // alert('请联系管理员...');
            layer.alert('请联系管理员...');
        }
    })
}