//初始化分页数据变量
var start = 0;
var end =1;
var limit = 3;
var currPage = 1; //当前页
var allPage = 1;//总页数
var count = 0;
//初始化搜索数据变量
var fileName = '';
var sTime = '';
var eTime = '';
//角色信息的全局
var file = null;
getList();
function getList() {
    $.ajax({
        url: './shouyefile.do',
        type: 'GET',
        data:{
            start:start,
            end:limit,
            fileName:fileName,
            sTime:sTime,
            eTime:eTime
        },
        dataType: 'JSON',
        success: function (resp) {
            console.log(resp);
            file = resp.datas.file;
            count = resp.datas.counts;
            if (file == null || file.length == 0){
                currPage = 0;
                allPage = 0;
                layer.alert("暂无数据");
                document.getElementById('fileDatas').innerHTML = '';
            }else {
                var str = '';
                for (var i = 0;i<file.length;i++){
                    str += `
                <tr>
                    <td>${file[i].fileName}</td>
                    <td>${file[i].fileSize}</td>
                    <td>${file[i].fileDate}</td>
                    <td>${file[i].userName}</td>
                    <td>${file[i].fileTypeName}</td>
                    <td>${file[i].fileScore}</td>
                    <td>${file[i].fileName}</td>
                     <td>${file[i].dowmloadNum}</td>
                    <td>
                    <button class="btn btn-mini" type="button" onclick="dowmLoadFile(${file[i].id})">下载文件</button>
                    </td>
                </tr>
                        `;
                }
                document.getElementById('fileDatas').innerHTML = str;

                //初始化分页数据
                allPage = count%limit ==0?(count/limit):parseInt(count/limit+1);
                document.getElementById('pageNum').innerHTML = currPage+"/"+allPage;

            }
        },
        error: function (resp) {
            layer.alert("请联系管理员")
        }
    })
}


//上一页
function prevPage() {
    if (currPage == 1){
        layer.alert("已经是第一页了。")
    }else {
        currPage--;
        start -=limit;
        end-=limit;
        getList();
    }
}
//下一页
function nextPage() {
    if (currPage == allPage){
        layer.alert("没有下一页了。")
    }else {
        currPage++;
        start +=limit;
        end+=limit;
        getList();
    }
}
//搜索
function doSearch() {
    start = 0;
    end =1;
    limit = 3;
    currPage = 1; //当前页
    allPage = 1;//总页数
    count = 0;
//初始化搜索数据变量
    fileName = document.getElementById('fileName').value;
    sTime = document.getElementById('sTime').value;
    eTime = document.getElementById('eTime').value;
    getList();
}
//重置
function doReset() {
    $('#fileName').val('');
    $('#sTime').val('');
    $('#eTime').val('');
}

//文件下载
function dowmLoadFile(id) {
    data={
        id:id
    }
    $.ajax({
        url:'./dowmLoadFile.do',
        type:'POST',
        dataType:'JSON',
        data:data,
        success:function (resp) {
            console.log(resp)
            if (resp.id==0){
                window.location.href = "fileDowmload.do";
            }
        },
        error:function (resp) {
            layer.alert(resp.msg)
        }

    })


}
