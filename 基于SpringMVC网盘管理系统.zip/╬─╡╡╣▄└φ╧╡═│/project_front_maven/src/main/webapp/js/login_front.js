function doLogin() {
    var password = val('pwd');
    //利用公钥加密
    var encrypt = new JSEncrypt();
    encrypt.setPublicKey($("#publicKey").val());
    var d = encrypt.encrypt(password);
    var ps = encodeURI(d).replace(/\+/g, '%2B');
    layer.load(2);
    var data = {
        action: 'doLogin',
        name: val('name'),
        pwd: ps,
        code:val('code')
    };
    $.ajax({
        url: './doLogin.do',
        type: 'POST',
        data: data,
        dataType: 'JSON',
        success: function (resp) {
            layer.closeAll('loading');
            layer.alert(resp.msg, {
                closeBtn: 0
            }, function () {
                if (resp.id == 0) {
                    window.location.href = 'page.do?p=' + resp.location;
                }
            });
        },
        error: function (resp) {
            layer.closeAll('loading');
            // alert('请联系管理员...');
            layer.alert(resp.msg);
        }

    })
}

//验证码的刷新
function changeImg() {
    var src = './captcha.do' + '?' + Math.random() ;
    set('capt-img', 'src', src);
}


$.ajax({
    url: './rasPublicKey.do',
    type: 'get',
    dataType: 'JSON',
    success: function (resp) {
        layer.closeAll('loading');
        if (resp.id != 0) {
            layer.alert(resp.msg);
            return;
        }
        // document.getElementById("publicKey").value = resp.msg;
        $("#publicKey").val(resp.msg);
    },
    error: function (resp) {
        layer.closeAll('loading');
        layer.alert('请联系管理员...');
    }
});
