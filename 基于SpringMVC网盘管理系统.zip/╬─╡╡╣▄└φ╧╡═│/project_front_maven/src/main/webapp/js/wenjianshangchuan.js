var _file = [];
$('#uploaderExample').uploader({
    // autoUpload: true,            // 当选择文件后立即自动进行上传操作
    url: 'uploader.do',  // 文件上传提交地址
    lang: 'zh_cn', // 设置为简体中文
    filters:  { // 文件上传的过滤配置
        // 只允许上传图片或图标（.ico）
        mime_types: [
            {title: '图片', extensions: 'jpg,gif,png'},
            {title: '图标', extensions: 'ico'},
            {title: '文本文档', extensions: 'txt'},
            {title: '视频', extensions: 'MP4,AVI,MOV,'},
            {title: '压缩包', extensions: 'zip'},
            {title: '音乐', extensions: 'MP3,wav'},
            {title: 'word', extensions: 'docx'}
        ],
        // 最大上传文件为 1MB
        max_file_size: '100mb',
        // 不允许上传重复文件
        prevent_duplicates: true
    },
    responseHandler: function(responseObject, file) { // 回调函数
        // 参数：1.响应信息；2.文件对象信息
        console.log(responseObject, file);
        _file = file;//全局变量
        document.getElementById("fileName").value = file.name;
    },
    chunk_size: 0, // 不启动分片上传
});

function commitFile() {
    var data={
        fileName:_file.name,
        fileType:_file.ext,
        fileSize:_file.size,
        fileScore:document.getElementById('fileScore').value,
    }
    $.ajax({
        url: './docommitFile.do',
        type: 'POST',
        data:data,
        dataType: 'JSON',
        success: function (resp) {
             console.log(resp);
            layer.alert(resp.msg)
        },
        error: function (resp) {
            layer.alert(resp.msg)
        }
    })
}